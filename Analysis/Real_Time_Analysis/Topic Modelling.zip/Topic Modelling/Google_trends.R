#GET THE GOOGLE TRENDS DATA FOR PAPER 5 - EMERGING TOPIC MODELLING
rm(list = ls())

#Import gtrendsR
install.packages("readr")
install.packages("colorspace")
install.packages("vctrs")
install.packages("gtrendsR")
library(gtrendsR)
#Help function
?gtrends

############################################################################################
#Ukraine Corrections 
res <- gtrends("Ukraine", time = "2023-02-04 2023-03-23")
plot(res)



#Test Case
res <- gtrends("Ukraine", time = "2021-12-01 2022-04-30")
plot(res)
df_res_ukraine <- res$interest_over_time
write.csv(df_res_ukraine, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Ukraine.csv")

#English Daily Topics
#Topic 1
res2 <- gtrends("Ukraine War", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_Ukraine<- res2$interest_over_time
write.csv(df_res_en_Ukraine, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/Ukraine_War.csv")

#Topic 2
res2 <- gtrends("South China Sea", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_SCS<- res2$interest_over_time
write.csv(df_res_en_SCS, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/South_China_Sea_En.csv")

#Topic 3
res2 <- gtrends("China", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_China<- res2$interest_over_time
write.csv(df_res_en_China, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/China_En.csv")

#Topic 4
res2 <- gtrends("Russian Oil", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_RO<- res2$interest_over_time
write.csv(df_res_en_RO, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/Russian_Oil_En.csv")

#Topic 5
res2 <- gtrends("Pakistan", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_Pak<- res2$interest_over_time
write.csv(df_res_en_RO, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/Pak_En.csv")

#Topic 6
res2 <- gtrends("North Korea", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_NK<- res2$interest_over_time
write.csv(df_res_en_NK, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/NK_En.csv")

#Topic 7
res2 <- gtrends("Iran Nuclear Program", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_INP<- res2$interest_over_time
write.csv(df_res_en_INP, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/IranNP_En.csv")

#Topic 8
res2 <- gtrends("Pemex Mexico", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_PMOF<- res2$interest_over_time
write.csv(df_res_en_PMOF, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/PMOF_En.csv")

#Topic 9
res2 <- gtrends("Nordstream Pipeline", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_NordP<- res2$interest_over_time
write.csv(df_res_en_NordP, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/NordP_En.csv")

#Topic 10
res2 <- gtrends("Karachi Police Station", hl = "en", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_en_KarPS<- res2$interest_over_time
write.csv(df_res_en_KarPS, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/English/KarPS_En.csv")

##############################################################################################################
#English Daily Topics
#Topic 1
res2 <- gtrends("Ukraine War", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_Ukraine<- res2$interest_over_time
write.csv(df_res_es_Ukraine, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/Ukraine_War_es.csv")
res2$related_topics

#Topic 2
res2 <- gtrends("Violence against Women", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_VaW<- res2$interest_over_time
write.csv(df_res_es_VaW, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/VaW_es.csv")
res2$related_topics

#Topic 3
res2 <- gtrends("Terrorism", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_T<- res2$interest_over_time
write.csv(df_res_es_T, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/Terrorism_es.csv")
res2$related_topics

#Topic 4
res2 <- gtrends("Nuclear Weapons", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_NW<- res2$interest_over_time
write.csv(df_res_es_NW, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/NW_es.csv")
res2$related_topics

#Topic 5
res2 <- gtrends("Irene Montero", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_IreneM- res2$interest_over_time
write.csv(df_res_es_IreneM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/IreneM_es.csv")
res2$related_topics

#Topic 6
res2 <- gtrends("Irene Montero", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_IreneM <- res2$interest_over_time
write.csv(df_res_es_IreneM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/IreneM_es.csv")
res2$related_topics

#Topic 7
res2 <- gtrends("United States", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_US <- res2$interest_over_time
write.csv(df_res_es_US, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/US_es.csv")
res2$related_topics

#Topic 8
res2 <- gtrends("Peru", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_Peru <- res2$interest_over_time
write.csv(df_res_es_Peru, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/Peru_es.csv")
res2$related_topics

#Topic 10
res2 <- gtrends("Ecuador Albania", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_EAM <- res2$interest_over_time
write.csv(df_res_es_EAM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/EAM_es.csv")
res2$related_topics

#Topic Test
res2 <- gtrends("Omar Menendez", hl = "es", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_OM <- res2$interest_over_time
write.csv(df_res_es_OM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Spanish/OM_es.csv")
res2$related_topics

##########################################################################################################
#French Topics
#Topic 3
res2 <- gtrends("Cyber Attacks", hl = "fr", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_CA <- res2$interest_over_time
write.csv(df_res_es_CA, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/French/CA_fr.csv")
res2$related_topics

#Topic 4
res2 <- gtrends("Israel", hl = "fr", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_es_Israel <- res2$interest_over_time
write.csv(df_res_es_Israel, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/French/Israel_fr.csv")
res2$related_topics

#Topic 6
res2 <- gtrends("Norway Russian", hl = "fr", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_fr_RS <- res2$interest_over_time
write.csv(df_res_fr_RS, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/French/RS_fr.csv")
res2$related_topics

#Topic 7
res2 <- gtrends("US - China Relations", hl = "fr", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_fr_USC <- res2$interest_over_time
write.csv(df_res_fr_USC, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/French/USC_fr.csv")
res2$related_topics

#Topic 10
res2 <- gtrends("American Military", hl = "fr", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_fr_AM <- res2$interest_over_time
write.csv(df_res_fr_AM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/French/AM_fr.csv")
res2$related_topics

###############################################################################################################
#Portuguese Topics
#Topic 2
res2 <- gtrends("Brazil Tax", hl = "pt", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_pt_BOET <- res2$interest_over_time
write.csv(df_res_pt_BOET, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Portuguese/BOET_pt.csv")
res2$related_topics

#Topic 3
res2 <- gtrends("Nuclear Attack", hl = "pt", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_pt_NA <- res2$interest_over_time
write.csv(df_res_pt_NA, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Portuguese/NA_pt.csv")
res2$related_topics

#Topic 6
res2 <- gtrends("START Treaty", hl = "pt", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_pt_ST <- res2$interest_over_time
write.csv(df_res_pt_ST, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Portuguese/ST_pt.csv")
res2$related_topics

#Topic 8
res2 <- gtrends("Russia - Brazil Relations", hl = "pt", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_pt_RB <- res2$interest_over_time
write.csv(df_res_pt_RB, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Portuguese/RB_pt.csv")
res2$related_topics

#Topic 9
res2 <- gtrends("Bolsonaro", hl = "pt", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_pt_BolJ <- res2$interest_over_time
write.csv(df_res_pt_BolJ, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Portuguese/BolJ_pt.csv")
res2$related_topics

#Topic 10
res2 <- gtrends("Brazil Congress", hl = "pt", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_pt_BC <- res2$interest_over_time
write.csv(df_res_pt_BC, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Portuguese/BC_pt.csv")
res2$related_topics

###########################################################################################################
#Arabic Topics
#Topic 4
res2 <- gtrends("Yemen Civil War", hl = "ar", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ar_YCW <- res2$interest_over_time
write.csv(df_res_ar_YCW, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Arabic/YCW_ar.csv")
res2$related_topics

#Topic 6
res2 <- gtrends("Russia", hl = "ar", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ar_Rus <- res2$interest_over_time
write.csv(df_res_ar_Rus, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Arabic/Rus_ar.csv")
res2$related_topics

#Topic 7
res2 <- gtrends("Iraq", hl = "ar", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ar_Iraq <- res2$interest_over_time
write.csv(df_res_ar_Iraq, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Arabic/Iraq_ar.csv")
res2$related_topics

#Topic 10
res2 <- gtrends("China Saudi Iran", hl = "ar", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ar_CSI <- res2$interest_over_time
write.csv(df_res_ar_CSI, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Arabic/CSI_ar.csv")
res2$related_topics

##############################################################################################################
#Japanese Topics
#Topic 2
res2 <- gtrends("Crude Oil", hl = "ja", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ja_CO <- res2$interest_over_time
write.csv(df_res_ja_CO, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Japanese/CO_ja.csv")
res2$related_topics

#Topic 4
res2 <- gtrends("Self - Defense Force", hl = "ja", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ja_SDF <- res2$interest_over_time
write.csv(df_res_ja_SDF, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Japanese/SDF_ja.csv")
res2$related_topics

#Topic 6
res2 <- gtrends("Hyper Sonic Missile", hl = "ja", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ja_HSM <- res2$interest_over_time
write.csv(df_res_ja_HSM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Japanese/HSM_ja.csv")
res2$related_topics

#Topic 7
res2 <- gtrends("Japan - US Relations", hl = "ja", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ja_JUS <- res2$interest_over_time
write.csv(df_res_ja_JUS, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Japanese/JUS_ja.csv")
res2$related_topics

#Topic 8
res2 <- gtrends("PM Cabinet", hl = "ja", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ja_PMCM <- res2$interest_over_time
write.csv(df_res_ja_PMCM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Japanese/PMCM_ja.csv")
res2$related_topics

#Topic 10
res2 <- gtrends("China Balloon", hl = "ja", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ja_ChinaB <- res2$interest_over_time
write.csv(df_res_ja_ChinaB, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Japanese/ChinaB_ja.csv")
res2$related_topics

#########################################################################################################
#Korean Topics
#Topic 6
res2 <- gtrends("US Fed", hl = "ko", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ko_USF <- res2$interest_over_time
write.csv(df_res_ko_USF, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Korean/USF_ko.csv")
res2$related_topics

#Topic 7
res2 <- gtrends("Lee Jae", hl = "ko", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ko_LJM <- res2$interest_over_time
write.csv(df_res_ko_LJM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Korean/LJM_ko.csv")
res2$related_topics

#Topic 9
res2 <- gtrends("Korea PMI", hl = "ko", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ko_SKPMI <- res2$interest_over_time
write.csv(df_res_ko_SKPMI, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Korean/SKPMI_ko.csv")
res2$related_topics

#Topic 10
res2 <- gtrends("Japan and South Korea", hl = "ko", time = "2023-02-04 2023-03-23")
plot(res2)
df_res_ko_JSK <- res2$interest_over_time
write.csv(df_res_ko_JSK, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Korean/JSK_ko.csv")
res2$related_topics

##############################################################################################################################################
#Hourly Tests
#Test 1
res <- gtrends("Ukraine", time = "now 7-d")
plot(res)
df_res_ukraine <- res$interest_over_time

#Test 2
res <- gtrends("Ukraine", time = "2021-12-01 2021-12-02")
plot(res)
df_res_ukraine <- res$interest_over_time

##############################################################################################################################################
#NER Locations Google Trends
#1. Ukraine
res <- gtrends("Ukraine", time = "2021-12-01 2022-04-30")
plot(res)
df_res_ukraine <- res$interest_over_time
write.csv(df_res_ukraine, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Ukraine.csv")

#2. Russia
res <- gtrends("Russia", time = "2021-12-01 2022-04-30")
plot(res)
df_res_rus <- res$interest_over_time
write.csv(df_res_rus, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Russia.csv")

#3. USA
res <- gtrends("USA", time = "2021-12-01 2022-04-30")
plot(res)
df_res_usa <- res$interest_over_time
write.csv(df_res_usa, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/USA.csv")

#4. China
res <- gtrends("China", time = "2021-12-01 2022-04-30")
plot(res)
df_res_china <- res$interest_over_time
write.csv(df_res_china, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/China.csv")

#5. Belarus
res <- gtrends("Belarus", time = "2021-12-01 2022-04-30")
plot(res)
df_res_bel <- res$interest_over_time
write.csv(df_res_bel, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Belarus.csv")

#6. Japan
res <- gtrends("Japan", time = "2021-12-01 2022-04-30")
plot(res)
df_res_japan <- res$interest_over_time
write.csv(df_res_japan, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Japan.csv")

#7. Moscow
res <- gtrends("Moscow", time = "2021-12-01 2022-04-30")
plot(res)
df_res_mos <- res$interest_over_time
write.csv(df_res_mos, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Moscow.csv")

#8. Germany
res <- gtrends("Germany", time = "2021-12-01 2022-04-30")
plot(res)
df_res_ger <- res$interest_over_time
write.csv(df_res_ger, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Germany.csv")

#9. Poland
res <- gtrends("Poland", time = "2021-12-01 2022-04-30")
plot(res)
df_res_pol <- res$interest_over_time
write.csv(df_res_pol, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Poland.csv")

#10. UK
res <- gtrends("UK", time = "2021-12-01 2022-04-30")
plot(res)
df_res_uk <- res$interest_over_time
write.csv(df_res_uk, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/UK.csv")

#11. Taiwan
res <- gtrends("Taiwan", time = "2021-12-01 2022-04-30")
plot(res)
df_res_tai <- res$interest_over_time
write.csv(df_res_tai, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Taiwan.csv")

#12. Myanmar
res <- gtrends("Myanmar", time = "2021-12-01 2022-04-30")
plot(res)
df_res_mya <- res$interest_over_time
write.csv(df_res_mya, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Myanmar.csv")

#13. Sweden
res <- gtrends("Sweden", time = "2021-12-01 2022-04-30")
plot(res)
df_res_swe <- res$interest_over_time
write.csv(df_res_swe, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Sweden.csv")

#14. Kyiv
res <- gtrends("Kyiv", time = "2021-12-01 2022-04-30")
plot(res)
df_res_kyiv <- res$interest_over_time
write.csv(df_res_kyiv, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Kyiv.csv")

#15. Estonia
res <- gtrends("Estonia", time = "2021-12-01 2022-04-30")
plot(res)
df_res_est <- res$interest_over_time
write.csv(df_res_est, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Estonia.csv")

#16. Israel
res <- gtrends("Israel", time = "2021-12-01 2022-04-30")
plot(res)
df_res_isr <- res$interest_over_time
write.csv(df_res_isr, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Israel.csv")

#17. Afghanistan
res <- gtrends("Afghanistan", time = "2021-12-01 2022-04-30")
plot(res)
df_res_afg <- res$interest_over_time
write.csv(df_res_afg, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Afghanistan.csv")

#18. Canada
res <- gtrends("Canada", time = "2021-12-01 2022-04-30")
plot(res)
df_res_can <- res$interest_over_time
write.csv(df_res_can, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/Canada.csv")

#19. France
res <- gtrends("France", time = "2021-12-01 2022-04-30")
plot(res)
df_res_fra <- res$interest_over_time
write.csv(df_res_fra, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Places/France.csv")

##############################################################################################################
#English Historical Topics
#Topic 1: 
res2 <- gtrends("Ukraine War", hl = "en", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_Ukraine<- res2$interest_over_time
write.csv(df_res_en_Ukraine, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/English/Ukraine_War.csv")
res2$related_topics

#Topic 2: 
res2 <- gtrends("Myanmar Protests", hl = "en", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_Myanmar<- res2$interest_over_time
write.csv(df_res_en_Myanmar, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/English/Myanmar_Protests.csv")
res2$related_topics

#Topic 3: 
res2 <- gtrends("Ethopia", hl = "en", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_ET<- res2$interest_over_time
write.csv(df_res_en_ET, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/English/Ethopia.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("Israel Palestine", hl = "en", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_IP<- res2$interest_over_time
write.csv(df_res_en_IP, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/English/IAP.csv")
res2$related_topics

#Spanish Historical Topics
#Topic 2: 
res2 <- gtrends("Economic Aid", hl = "es", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_EA<- res2$interest_over_time
write.csv(df_res_en_EA, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Spanish/EA_es.csv")
res2$related_topics

#Topic 3: 
res2 <- gtrends("Venezuela", hl = "es", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_Ven<- res2$interest_over_time
write.csv(df_res_en_Ven, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Spanish/Ven_es.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("US Military", hl = "es", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_USM<- res2$interest_over_time
write.csv(df_res_en_USM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Spanish/USM_es.csv")
res2$related_topics

#French Historical Topics
#Topic 2: 
res2 <- gtrends("Russian Mobilization", hl = "fr", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_RM<- res2$interest_over_time
write.csv(df_res_en_RM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/French/RM_fr.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("Mali", hl = "fr", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_Mali<- res2$interest_over_time
write.csv(df_res_en_Mali, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/French/Mali_fr.csv")
res2$related_topics

#Portuguese Historical Topics
#Topic 2: 
res2 <- gtrends("Bolsonaro", hl = "pt", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_Bol<- res2$interest_over_time
write.csv(df_res_en_Bol, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Portuguese/Bol_pt.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("Brazil Military", hl = "pt", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_BM<- res2$interest_over_time
write.csv(df_res_en_BM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Portuguese/BM_pt.csv")
res2$related_topics

#Arabic Historical Topics
#Topic 2: 
res2 <- gtrends("Yemen Civil War", hl = "ar", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_YCM<- res2$interest_over_time
write.csv(df_res_en_YCM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Arabic/YCM_ar.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("Iraq", hl = "ar", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_Iraq<- res2$interest_over_time
write.csv(df_res_en_Iraq, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Arabic/Iraq_ar.csv")
res2$related_topics

#Japanese Historical Topics
#Topic 1: 
res2 <- gtrends("Economic Support", hl = "ja", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_ES<- res2$interest_over_time
write.csv(df_res_en_ES, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Japanese/EconS_ja.csv")
res2$related_topics

#Topic 3: 
res2 <- gtrends("PM Kishida", hl = "ja", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_PMK<- res2$interest_over_time
write.csv(df_res_en_PMK, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Japanese/PMK_ja.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("Japan and South Korea", hl = "ja", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_JSK<- res2$interest_over_time
write.csv(df_res_en_JSK, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Japanese/JSK_ja.csv")
res2$related_topics

#Korean Historical Topics
#Topic 2: 
res2 <- gtrends("Yoon Seok-yeol", hl = "ko", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_YSY <- res2$interest_over_time
write.csv(df_res_en_YSY, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Korean/YSY_ko.csv")
res2$related_topics

#Topic 3: 
res2 <- gtrends("End Korean War", hl = "ko", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_KW<- res2$interest_over_time
write.csv(df_res_en_KW, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Korean/KW_ko.csv")
res2$related_topics

#Topic 4: 
res2 <- gtrends("Lee Jae-myung", hl = "ko", time = "2021-12-01 2022-04-30")
plot(res2)
df_res_en_LJM <- res2$interest_over_time
write.csv(df_res_en_LJM, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Historical/Topics/Korean/LJM_ko.csv")
res2$related_topics

############################################################################################################

#Hourly Tests
#June 1st Real Time Test
res <- gtrends("Iran", hl = "en",  time = "now 4-H")
plot(res)
df_res_iran <- res$interest_over_time
write.csv(df_res_iran, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/English/Iran_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Nuclear Weapons", hl = "en",  time = "now 4-H")
plot(res)
df_res_iran <- res$interest_over_time
write.csv(df_res_iran, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/English/NW_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("South China Sea", hl = "en",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/English/SCS_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Ballistic Missile", hl = "ja",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/Japanese/BM_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Ukraine", hl = "fr",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/French/Ukr_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Ukraine", hl = "fr",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/French/Ukr_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Ukraine", hl = "fr",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/French/Ukr_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Reconnaisance", hl = "ko",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/Korean/RS_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Satellite", hl = "ko",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/Korean/RS2_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("America Ambassador", hl = "ko",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/Korean/AA_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Women Political Violence", hl = "es",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/Spanish/T_6_1_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Iraq", hl = "ar",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_1_2023/Arabic/Iraq_6_1_2023.csv")
res$related_topics

###############################################################################################################

#Hourly Tests 2
#June 6th Real Time Test
res <- gtrends("kakhovka", hl = "en",  time = "now 4-H")
plot(res)
df_res_iran <- res$interest_over_time
write.csv(df_res_iran, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/English/kakhovka_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("South China Sea", hl = "en",  time = "now 4-H")
plot(res)
df_res_iran <- res$interest_over_time
write.csv(df_res_iran, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/English/SCS_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("nova", hl = "en",  time = "now 4-H")
plot(res)
df_res_iran <- res$interest_over_time
write.csv(df_res_iran, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/English/nova_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("OPEC", hl = "ar",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Arabic/OPEC_6_6_2023.csv")
res$related_topics

#June 1st Real Time Test
res <- gtrends("Saudi Arabia", hl = "ar",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Arabic/Saudi_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Iran", hl = "fr",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/French/Iran_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("cyberattack", hl = "fr",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/French/cyberattack_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Macron", hl = "ja",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Japanese/Macron_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Nuclear Weapons", hl = "ja",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Japanese/NW_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Nuclear Weapons", hl = "ja",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Japanese/NW_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Crude Oil", hl = "ja",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Japanese/CO_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Crude Oil", hl = "ja",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Japanese/CO_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Russian Nuclear", hl = "pt",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Portuguese/RN_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Irene Montero", hl = "es",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Spanish/IreneM_6_6_2023.csv")
res$related_topics

#June 6th Real Time Test
res <- gtrends("Pablo", hl = "es",  time = "now 4-H")
plot(res)
df_res_scs <- res$interest_over_time
write.csv(df_res_scs, "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/Topic Modelling/Google_Trends/Hourly/June_6_2023/Spanish/PabloIT_6_6_2023.csv")
res$related_topics


#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Dynamic Adaption Test 2
#English Only
#Hours Tests


# In[ ]:


#Topic Modelling Functionalization


# In[ ]:


#Step 0: Libraries


# In[165]:


#Part 1: The Glob Libraries
#https://stackoverflow.com/questions/57067551/how-to-read-multiple-json-files-into-pandas-dataframe
#/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 9/foo5/json_file
import os
import json
import pandas as pd
import numpy as np
import glob
pd.set_option('display.max_columns', 500)
import csv
import time
import requests
import math


# In[2]:


#Part 2: Lang Detect Libraries
#Get the language labels for the dataset
#Enforce consistent results 
from langdetect import DetectorFactory
DetectorFactory.seed = 0
#Import the detect function
from langdetect import detect


# In[3]:


#Step 3: Topics over Time Libraries
import numpy as np
from pprint import pprint
import gensim
import gensim.corpora as corpora
from gensim.utils import simple_preprocess
from gensim.models import CoherenceModel
import gensim.test.utils
import spacy
import en_core_web_sm
import nltk
from nltk.corpus import stopwords
import tqdm


# In[4]:


#Step 4: Pretty Printing Library
from pprint import pprint


# In[5]:


#Step 5: Making the Plot Library
#Graphing in Jupiter Notebook
import random
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[6]:


#Step 6: Translation Library
from deep_translator import GoogleTranslator


# In[7]:


#Step 7: The Arabic Tokenization Packages
#Import the dediacritization tool
#Lemmaziation is quite complicated, building my own would require a level of Arabic knowledge that I don't pocess, 
#while the current tools that are available are either restricted by the creators to only a set number of uses a day
#Or have bugs making them not usable. I have settled for a tokenizer which will get the job done. Explain what makes 
#Arabic lemmaziation so difficult
#https://towardsdatascience.com/arabic-nlp-unique-challenges-and-their-solutions-d99e8a87893d
#https://github.com/CAMeL-Lab/camel_tools
#from camel_tools.utils.dediac import dediac_ar
#Reducing Orthographic Ambiguity
#from camel_tools.utils.normalize import normalize_alef_maksura_ar
#from camel_tools.utils.normalize import normalize_alef_ar
#from camel_tools.utils.normalize import normalize_teh_marbuta_ar
#Tokenizer
#from camel_tools.tokenizers.word import simple_word_tokenize


# In[8]:


#Step 7.5: Orthographic Ambiguity Function for Arabic
#def ortho_normalize(text):
#    text = normalize_alef_maksura_ar(text)
#    text = normalize_alef_ar(text)
#    text = normalize_teh_marbuta_ar(text)
#    return text


# In[9]:


#Step 8: The Korean Lemmatizer packages and functions
from soylemma import Lemmatizer
lemmatizer = Lemmatizer()


# In[10]:


#Step 1: The Helper Files and Constant Variables


# In[11]:


#Part 1: Set the path to the json 
#path_to_json = "/Users/johnc.burns/Documents/Documents/PhD Year Two/My Paper 2/Test Json Tweets 1"
path_to_json = "/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/json_file"


# In[12]:


#Part 2: Set Counter variable
counter_tm = 0


# In[13]:


#Part 3: Arabic Lemma API Keys 
#url_ar_api = 'https://farasa.qcri.org/webapi/lemmatization/'
#api_key_ar_api = "ZkLoQQwVKknVObUVPa"


# In[14]:


#Step 2: Writing the Functions:


# In[15]:


#Part 1: Get all files from Json_file output
def all_files(path_to_json):
    json_pattern = os.path.join(path_to_json, '*.json')
    file_list = glob.glob(json_pattern)
    #Import the jsons and convert them to pandas dataframes
    dfs = []
    for file in file_list:
        data = pd.read_json(file)
        dfs.append(data)
    #Concat the individual data frames into one dataframe
    full_tm = pd.concat(dfs, ignore_index = True)
    #Reset Index
    ftm2 = full_tm.reset_index(drop = True)
    return ftm2


# In[16]:


#Step 2: Language detect Function
def lang_detect_2(text):
    detectanswer = detect(text)
    return detectanswer


# In[17]:


#Step 3: Set up the language detection loop Function
def lang_loop(df):
    #Get Length of dataframe
    lendf = len(df)
    #Create new column with string
    df['lang'] = ""
    #Use the language Detect function to get the language of the text
    for i in range(0, lendf):
        try:
            df["lang"][i] = lang_detect_2(df["text"][i])
        except:
            df["lang"][i] = "und"
    return df


# In[18]:


#Part 4: Break into English Tweets
def English_Tweets_Func(df_gt):
    English_Tweets = df_gt[df_gt['lang'] == "en"]
    English_Tweets.reset_index(drop = True, inplace = True)
    English_Tweets['TweetNumber'] = np.arange(len(English_Tweets))
    return English_Tweets


# In[19]:


#Part 5: Break into Spanish Tweets
def Spanish_Tweets_Func(df_gt):
    Spanish_Tweets = df_gt[df_gt['lang'] == "es"]
    Spanish_Tweets.reset_index(drop = True, inplace = True)
    Spanish_Tweets['TweetNumber'] = np.arange(len(Spanish_Tweets))
    return Spanish_Tweets


# In[20]:


#Part 6: Break into French Tweets
def French_Tweets_Func(df_gt):
    French_Tweets = df_gt[df_gt['lang'] == "fr"]
    French_Tweets.reset_index(drop = True, inplace = True)
    French_Tweets['TweetNumber'] = np.arange(len(French_Tweets))
    return French_Tweets


# In[21]:


#Part 7: Break into Portuguese Tweets
def Portuguese_Tweets_Func(df_gt):
    Portuguese_Tweets = df_gt[df_gt['lang'] == "pt"]
    Portuguese_Tweets.reset_index(drop = True, inplace = True)
    Portuguese_Tweets['TweetNumber'] = np.arange(len(Portuguese_Tweets))
    return Portuguese_Tweets


# In[22]:


#Part 8: Break into Arabic Tweets
def Arabic_Tweets_Func(df_gt):
    Arabic_Tweets = df_gt[df_gt['lang'] == "ar"]
    Arabic_Tweets.reset_index(drop = True, inplace = True)
    Arabic_Tweets['TweetNumber'] = np.arange(len(Arabic_Tweets))
    return Arabic_Tweets
    #print( Arabic_Tweets)


# In[23]:


#Part 9: Break into Japanese Tweets
def Japanese_Tweets_Func(df_gt):
    Japanese_Tweets = df_gt[df_gt['lang'] == "ja"]
    Japanese_Tweets.reset_index(drop = True, inplace = True)
    Japanese_Tweets['TweetNumber'] = np.arange(len(Japanese_Tweets)) 
    return Japanese_Tweets


# In[24]:


#Part 10: Break into Korean Tweets
def Korean_Tweets_Func(df_gt):
    Korean_Tweets = df_gt[df_gt['lang'] == "ko"]
    Korean_Tweets.reset_index(drop = True, inplace = True)
    Korean_Tweets['TweetNumber'] = np.arange(len(Korean_Tweets))
    return Korean_Tweets


# In[25]:


#Step 11: Create the Date Function
def date_func(df):
    df["Date"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Date"][i] = str(df["created_at"][i])
    return df


# In[26]:


#Step 12: Create the Year Function
def year_func(df):
    df["Year"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Year"][i] = int(df["Date"][i][0:4]) 
    return df


# In[27]:


#Step 13: Create the Month Function
def month_func(df):
    df["Month"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Month"][i] = int(df["Date"][i][5:7])
    return df


# In[28]:


#Step 14: Create the Day Function
def day_func(df):
    df["Day"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Day"][i] = int(df["Date"][i][8:10])
    return df


# In[29]:


#Step 15: Create the Hour Function
def hour_func(df):
    df["Hour"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Hour"][i] = int(df["Date"][i][11:13])
    return df


# In[30]:


#Step 16: Create the Minute Function
def minute_func(df):
    df["Minute"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Minute"][i] = int(df["Date"][i][14:16])
    return df


# In[31]:


#Step 17: Create the Second Function
def second_func(df):
    df["Second"] = ""
    lendf = len(df)
    for i in range(lendf):
        df["Second"][i] = int(df["Date"][i][17:19])
    return df


# In[215]:


#Step 17.5: Data Combos Function
def date_combos(df):
    df["Month_Day"] = 0
    df["Day_Hour"] = 0
    #df["Month_Day_Hour"] = 0 
    lendf = len(df)
    for i in range(0, lendf):
        df["Month_Day"][i] = ((((df["Month"][i]) - 1)*30) + df["Day"][i])
        df["Day_Hour"][i] = (((df["Day"][i])*24) + df["Hour"][i])
        #df["Month_Day_Hour"][i] = (((df["Month"][i])*730) + ((df["Day"][i])*24) + (df["Hour"][i]))
    return df


# In[32]:


#Step 18: Sort Chronologically Function Sort by the Year, Month, Day, Hour, Minute, Second
def sort_chrono(df):
    df2 = df.sort_values(by = ['Year', 'Month', 'Day', 'Hour', 'Minute', 'Second'], ascending = ['False', 'False', 'False', 'False', 'False', 'False'], na_position = 'first')
    df3 = df2.reset_index(drop = True)
    return df3


# In[33]:


#Step 19: English Stop Words Vector
def stopwords_en_func():
    stop_words_en = stopwords.words('english')
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_en = stop_words_en + custom_stop_words
    return final_stop_words_en


# In[34]:


#Step 20: Spanish Stop Words Vector
def stopwords_sp_func():
    stop_words_sp = stopwords.words('spanish')
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_sp = stop_words_sp + custom_stop_words
    return final_stop_words_sp


# In[35]:


#Step 21: French Stop Words Vector
def stopwords_fr_func():
    stop_words_fr = stopwords.words('french')
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_fr = stop_words_fr + custom_stop_words
    return final_stop_words_fr


# In[36]:


#Step 22: Portuguese Stop Words Vector
def stopwords_pt_func():
    stop_words_pt = stopwords.words('portuguese')
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_pt = stop_words_pt + custom_stop_words
    return final_stop_words_pt


# In[37]:


#Step 23: Arabic Stop Words Vector
def stopwords_ar_func():
    stop_words_ar = stopwords.words('arabic')
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_ar = stop_words_ar + custom_stop_words
    return final_stop_words_ar


# In[38]:


#Step 24: Get the Japanese Stopwords Vector
def stopwords_ja_func():
    stopwords_ja_df = pd.read_csv("/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/stopwords-ja.txt", delimiter = "\t", encoding = "utf-8")
    stopwords_ja_df.columns = ["word"]
    stopwords_ja = stopwords_ja_df["word"].values.tolist()
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_ja = stopwords_ja + custom_stop_words
    return final_stop_words_ja


# In[39]:


#Step 25: Import Korean Stop Words
def stopwords_ko_func():
    stopwords_ko_df = pd.read_csv("/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/stopwords-ko.txt", delimiter = "\t", quoting=csv.QUOTE_NONE, encoding = "utf-8")
    stopwords_ko_df.columns = ["word"]
    stopwords_ko = stopwords_ko_df["word"].values.tolist()
    custom_stop_words = ["http", "https", "co", "com", "app", "go", "amp", "RT", "rt"]
    final_stop_words_ko = stopwords_ko + custom_stop_words
    return final_stop_words_ko


# In[40]:


#Step 26: Remove Stop Words English
def stopwords_en(texts, final_stop_words_en):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_en] for doc in texts]


# In[41]:


#Step 27: Remove Stop Words Spanish
def stopwords_sp(texts, final_stop_words_sp):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_sp] for doc in texts]


# In[42]:


#Step 28: Remove Stop Words French
def stopwords_fr(texts, final_stop_words_fr):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_fr] for doc in texts]


# In[43]:


#Step 29: Remove Stop Words Portuguese
def stopwords_pt(texts, final_stop_words_pt):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_pt] for doc in texts]


# In[44]:


#Step 30: Remove Stop Words Arabic
def stopwords_ar(texts, final_stop_words_ar):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_ar] for doc in texts]


# In[45]:


#Step 31: Remove Stop Words Japanese
def stopwords_ja(texts, final_stop_words_ja):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_ja] for doc in texts]


# In[46]:


#Step 32: Remove Stop Words Korean
def stopwords_ko(texts, final_stop_words_ko):
    return[[word for word in simple_preprocess(str(doc)) if word not in final_stop_words_ko] for doc in texts]


# In[47]:


#Step 33: Make bigrams of the words
#Make sure do call this function 7 times for each of the 7 languages
def bigrams(texts):
    bigram = gensim.models.Phrases(texts, min_count = 5, threshold = 100)
    bigram_mod = gensim.models.phrases.Phraser(bigram)
    return [bigram_mod[doc] for doc in texts]


# In[48]:


#Step 34: Turn the words into lemmas English
def data_lemmatization_en(texts, allowed_postags = ['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    nlp = spacy.load('en_core_web_sm', disable = ['parser', 'ner'])
    nlp.max_length = 15000000
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent))
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out


# In[49]:


#Step 35: Turn the words into lemmas Spanish
def data_lemmatization_sp(texts, allowed_postags = ['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    nlp = spacy.load("es_core_news_sm", disable = ['parser', 'ner'])
    nlp.max_length = 15000000
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent))
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out


# In[50]:


#Step 36: Turn the words into lemmas French
def data_lemmatization_fr(texts, allowed_postags = ['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    nlp = spacy.load("fr_core_news_sm", disable = ['parser', 'ner'])
    nlp.max_length = 15000000
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent))
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out


# In[51]:


#Step 37: Turn the words into lemmas Portuguese
def data_lemmatization_pt(texts, allowed_postags = ['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    nlp = spacy.load("pt_core_news_sm", disable = ['parser', 'ner'])
    nlp.max_length = 15000000
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent))
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out


# In[52]:


#Step 38: Turn the words into lemmas Portuguese
def data_lemmatization_ja(texts, allowed_postags = ['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    nlp = spacy.load("ja_core_news_sm", disable = ['parser', 'ner'])
    nlp.max_length = 15000000
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent))
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out


# In[53]:


#Step 39: Arabic Lemmas 
#def data_lemmatization_ar(texts):
    #payload = {'text': texts, 'api_key': api_key_ar_api}
    #data = requests.post(url_ar_api, data=payload)
    #result = json.loads(data.text)
    #texts_out = result["text"]
    
    #return texts_out


# In[54]:


#Step 39: Arabic Tokens
def data_tokenization_ar(texts):
    d = {'text': [texts]}
    df_texts = pd.DataFrame(data = d)
    #dediacritization tool text column
    df_texts["arabic_text"] = df_texts["text"].apply(dediac_ar)
    #Reducing Orthographic Ambiguity
    df_texts["ar_text_or"] = df_texts["arabic_text"].apply(ortho_normalize)
    #Simple Word Tokenization
    df_texts["ar_tokens"] = df_texts["ar_text_or"].apply(simple_word_tokenize)
    #Convert token series to list
    texts_out = df_texts["ar_tokens"].tolist()
    return texts_out


# In[191]:


#Step 40: Korean Lemmas 
#https://stackoverflow.com/questions/60115806/pd-na-vs-np-nan-for-pandas
#https://stackoverflow.com/questions/21011777/how-can-i-remove-nan-from-list-python-numpy
def data_lemmatization_ko(texts):
    len_texts = len(texts)
    texts3 = []
    #print(type(texts))
    text10 = []
    for sent in texts:
        text1 = sent
        #print(type(text1))
        text2 = []
        lentext1 = len(text1)
        #print(lentext1)
        for i in range(0, lentext1):
            lem1 = lemmatizer.lemmatize(text1[i])
            #print(type(lem1))
            text10.append(lem1)
    #print(text10)
    #print(type(text10))
    #print(len(text10))
    #print(type(text10[0]))
    text_df = pd.DataFrame(text10, columns = ['Lists', 'Lists2', 'Lists3', 'Lists4'])
    tdf2 = text_df.dropna(how = "all")
    tdf3 = tdf2.reset_index(drop = True)
    #print(tdf3)
    #print(tdf3['Lists'][0])
    #print(type(tdf3['Lists'][0]))
    #print(tdf3["Lists"][0][0])
    #print(type(tdf3["Lists"][0][0]))
    text_list = []
    lentdf3 = len(tdf3["Lists"])
    for i in range(0, lentdf3):
        if np.nan != (tdf3["Lists"][i]):
            text_list.append(tdf3["Lists"][i])
    for i in range(0, lentdf3):
        if np.nan != (tdf3["Lists2"][i]):
            text_list.append(tdf3["Lists2"][i])
    for i in range(0, lentdf3):
        if np.nan != (tdf3["Lists3"][i]):
            text_list.append(tdf3["Lists3"][i])
    for i in range(0, lentdf3):
        if np.nan != (tdf3["Lists4"][i]):
            text_list.append(tdf3["Lists4"][i])
    #print(text_list)
    cleaned_text_list = [x for x in text_list if str(x) != 'None']
    #print(cleaned_text_list)
    #lenctl = len(cleaned_text_list)
    #print(len(cleaned_text_list))
    only_words = []
    for i in range(0, len(cleaned_text_list)):
        lem1 = cleaned_text_list[i]
        lem2 = lem1[0]
        only_words.append(lem2)
    #print(only_words)
    texts_out = only_words
    return texts_out


# In[56]:


#Step 41: Create topic_id numbers, change dynamically
#https://www.delftstack.com/howto/python/python-list-from-1-to-n/
#topic_id = [0, 1, 2, 3, 4, 5, 6, 7, 8]
def createList(n):
    lst1 = []
    for i in range(n):
        lst1.append(i)
    return(lst1)


# In[57]:


#Step 42: Detour to focus on hyperparameter tunning of the LDA Model
#https://towardsdatascience.com/evaluate-topic-model-in-python-latent-dirichlet-allocation-lda-7d57484bb5d0
#First build the function to test the hyperparameters of the number of topics (k), the document - topic density
#(alpha) and the Word - topic density (beta), we get the coherence score for each model using the 'c_v' which is 
#measure is based on a sliding window, one-set segmentation of the top words and an indirect confirmation 
#measure that uses normalized pointwise mutual information (NPMI) and the cosine similarity

def compute_coherence_values(corpus, texts, dictionary, k, a, b):

    lda_model_cv = gensim.models.LdaMulticore(corpus = corpus,
                                         id2word = dictionary,
                                         num_topics = k,
                                         random_state = 101,
                                         chunksize = 100,
                                         passes = 10,
                                         alpha = a,
                                         eta = b,
                                          per_word_topics = True,
                                          minimum_probability = 0)
    
    #coherence_model_lda = CoherenceModel(model = lda_model_cv, texts = data_lemma, dictionary = id2word,
    #                                    coherence = 'c_v')
    coherence_model_lda = CoherenceModel(model = lda_model_cv, texts = texts, 
                                         dictionary = dictionary, coherence = 'c_v')
    
    return coherence_model_lda.get_coherence()


# In[58]:


#####################################################################################################################


# In[59]:


#Step 43: LDA Hyperparameter Finding function for English
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
def lda_hyperparameter_generating_en(df_en, final_stop_words_en):
    #Remove stops words
    data_words_nostops_hf = stopwords_en(df_en['text'], final_stop_words_en)
    #Create the bigram from the non stop words
    data_words_bigram_hf = bigrams(data_words_nostops_hf)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma_hf = data_lemmatization_en(data_words_bigram_hf, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word_hf = corpora.Dictionary(data_lemma_hf)
    #Corpus
    texts_hf = data_lemma_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_lemma_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_en = pd.DataFrame(model_results)
    
    return mr_en


# In[60]:


#Step 44: Hyper Parameter Defining for English
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_en(mr_en):
    #Find the right number of topics
    mr2 = mr_en.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_en['Topics'] == top_opt
    mr_to = mr_en[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_en = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_en)
    return hyper_list_en


# In[61]:


#Step 45: Implement the stopwords, bigrams, and lemma functions English
def build_lda_en(df_en, final_stop_words_en, hyper_list_en):
    #Remove stops words
    data_words_nostops = stopwords_en(df_en['text'], final_stop_words_en)
    #Create the bigram from the non stop words
    data_words_bigram = bigrams(data_words_nostops)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma = data_lemmatization_en(data_words_bigram, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word = corpora.Dictionary(data_lemma)
    #Corpus
    texts = data_lemma
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_en = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_en[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_en[1],
                                              eta = hyper_list_en[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_en[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_en
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_en.print_topics()
    lenpt2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenpt2):
        pt_list = printtopics2[i][1].split('*')
        pt_list_words = []
        lenptl = len(pt_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = pt_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            pt_list_words.append(t_3)
        topic_label_list.append(pt_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_en = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_en


# In[218]:


#Step 46: Visualization of Topics over Time English
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_en(df, hyper_list_en, counter_tm):
    
    #Split Data into individual topics
    topic_dfs_en = {}
    topic_label_list_en = []
    for i in range(0, hyper_list_en[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list_en.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs_en[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors_en = hyper_list_en[0]
    
    color_en = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors_en)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs_en.keys():
        plt.plot(topic_dfs_en[i], color = color_en[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in English Topics")
    plt.xlabel("Hour") 
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list_en))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_EN_Hour_" + str(counter_tm))
    plt.close()

# In[63]:


####################################################################################################################


# In[64]:


#Step 47: LDA Hyperparameter Finding function for Spanish
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
def lda_hyperparameter_generating_sp(df_sp, final_stop_words_sp):
    #Remove stops words
    data_words_nostops_hf = stopwords_sp(df_sp['text'], final_stop_words_sp)
    #Create the bigram from the non stop words
    data_words_bigram_hf = bigrams(data_words_nostops_hf)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma_hf = data_lemmatization_sp(data_words_bigram_hf, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word_hf = corpora.Dictionary(data_lemma_hf)
    #Corpus
    texts_hf = data_lemma_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_lemma_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_sp = pd.DataFrame(model_results)
    
    return mr_sp


# In[65]:


#Step 48: Hyper Parameter Defining for Spanish
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_sp(mr_sp):
    #Find the right number of topics
    mr2 = mr_sp.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_sp['Topics'] == top_opt
    mr_to = mr_sp[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_sp = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_sp)
    return hyper_list_sp


# In[66]:


#Step 50: Implement the stopwords, bigrams, and lemma functions Spanish
def build_lda_sp(df_sp, final_stop_words_sp, hyper_list_sp):
    #Remove stops words
    data_words_nostops = stopwords_sp(df_sp['text'], final_stop_words_sp)
    #Create the bigram from the non stop words
    data_words_bigram = bigrams(data_words_nostops)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma = data_lemmatization_sp(data_words_bigram, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word = corpora.Dictionary(data_lemma)
    #Corpus
    texts = data_lemma
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_sp = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_sp[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_sp[1],
                                              eta = hyper_list_sp[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_sp[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_sp
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_sp.print_topics()
    lenpt2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenpt2):
        pt_list = printtopics2[i][1].split('*')
        pt_list_words = []
        lenptl = len(pt_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = pt_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            pt_list_words.append(t_3)
        topic_label_list.append(pt_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list
    
    #Translate the Topic Label 
    tll_translate = []
    lentll = len(topic_label_list)
    for i in range(0, lentll):
        tll_topic_line = []
        lent_t_l = len(topic_label_list[i])
        for j in range(0, lent_t_l):
            text = topic_label_list[i][j]
            translated = GoogleTranslator(source = "spanish", to_lang = "english").translate(text=text)
            tll_topic_line.append(translated)
        tll_translate.append(tll_topic_line)
        
    #Topic Label Translated 
    topic_labels_translate = tll_translate
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels_translate))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_sp = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_sp


# In[67]:


#Step 51: Visualization of Topics over Time Spanish
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_sp(df, hyper_list_sp, counter_tm):
    
    #Split Data into individual topics
    topic_dfs_sp = {}
    topic_label_list_sp = []
    for i in range(0, hyper_list_sp[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list_sp.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs_sp[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors_sp = hyper_list_sp[0]
    
    color_sp = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors_sp)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs_sp.keys():
        plt.plot(topic_dfs_sp[i], color = color_sp[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in Spanish Topics")
    plt.xlabel("Hour") 
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list_sp))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_SP_Hour_" + str(counter_tm))
    plt.close()

# In[68]:


#####################################################################################################################


# In[69]:


#Step 52: LDA Hyperparameter Finding function for French
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
def lda_hyperparameter_generating_fr(df_fr, final_stop_words_fr):
    #Remove stops words
    data_words_nostops_hf = stopwords_fr(df_fr['text'], final_stop_words_fr)
    #Create the bigram from the non stop words
    data_words_bigram_hf = bigrams(data_words_nostops_hf)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma_hf = data_lemmatization_fr(data_words_bigram_hf, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word_hf = corpora.Dictionary(data_lemma_hf)
    #Corpus
    texts_hf = data_lemma_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_lemma_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_fr = pd.DataFrame(model_results)
    
    return mr_fr


# In[70]:


#Step 53: Hyper Parameter Defining for French
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_fr(mr_fr):
    #Find the right number of topics
    mr2 = mr_fr.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_fr['Topics'] == top_opt
    mr_to = mr_fr[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_fr = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_fr)
    return hyper_list_fr


# In[71]:


#Step 54: Implement the stopwords, bigrams, and lemma functions Spanish
def build_lda_fr(df_fr, final_stop_words_fr, hyper_list_fr):
    #Remove stops words
    data_words_nostops = stopwords_fr(df_fr['text'], final_stop_words_fr)
    #Create the bigram from the non stop words
    data_words_bigram = bigrams(data_words_nostops)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma = data_lemmatization_fr(data_words_bigram, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word = corpora.Dictionary(data_lemma)
    #Corpus
    texts = data_lemma
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_fr = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_fr[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_fr[1],
                                              eta = hyper_list_fr[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_fr[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_fr
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_fr.print_topics()
    lenpt2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenpt2):
        pt_list = printtopics2[i][1].split('*')
        pt_list_words = []
        lenptl = len(pt_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = pt_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            pt_list_words.append(t_3)
        topic_label_list.append(pt_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list
    
    #Translate the Topic Label 
    tll_translate = []
    lentll = len(topic_label_list)
    for i in range(0, lentll):
        tll_topic_line = []
        lent_t_l = len(topic_label_list[i])
        for j in range(0, lent_t_l):
            text = topic_label_list[i][j]
            translated = GoogleTranslator(source = "french", to_lang = "english").translate(text=text)
            tll_topic_line.append(translated)
        tll_translate.append(tll_topic_line)
        
    #Topic Label Translated 
    topic_labels_translate = tll_translate
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels_translate))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_fr = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_fr


# In[72]:


#Step 55: Visualization of Topics over Time French
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_fr(df, hyper_list_fr, counter_tm):
    
    #Split Data into individual topics
    topic_dfs_fr = {}
    topic_label_list_fr = []
    for i in range(0, hyper_list_fr[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list_fr.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs_fr[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors_fr = hyper_list_fr[0]
    
    color_fr = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors_fr)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs_fr.keys():
        plt.plot(topic_dfs_fr[i], color = color_fr[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in French Topics")
    plt.xlabel("Hour") 
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list_fr))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_FR_Hour_" + str(counter_tm))
    plt.close()

# In[73]:


#####################################################################################################################


# In[74]:


#Step 56: LDA Hyperparameter Finding function for Portuguese
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
def lda_hyperparameter_generating_pt(df_pt, final_stop_words_pt):
    #Remove stops words
    data_words_nostops_hf = stopwords_pt(df_pt['text'], final_stop_words_pt)
    #Create the bigram from the non stop words
    data_words_bigram_hf = bigrams(data_words_nostops_hf)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma_hf = data_lemmatization_pt(data_words_bigram_hf, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word_hf = corpora.Dictionary(data_lemma_hf)
    #Corpus
    texts_hf = data_lemma_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_lemma_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_pt = pd.DataFrame(model_results)
    
    return mr_pt


# In[75]:


#Step 57: Hyper Parameter Defining for Portuguese
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_pt(mr_pt):
    #Find the right number of topics
    mr2 = mr_pt.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_pt['Topics'] == top_opt
    mr_to = mr_pt[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_pt = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_pt)
    return hyper_list_pt


# In[76]:


#Step 58: Implement the stopwords, bigrams, and lemma functions Portuguese
def build_lda_pt(df_pt, final_stop_words_pt, hyper_list_pt):
    #Remove stops words
    data_words_nostops = stopwords_pt(df_pt['text'], final_stop_words_pt)
    #Create the bigram from the non stop words
    data_words_bigram = bigrams(data_words_nostops)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma = data_lemmatization_pt(data_words_bigram, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word = corpora.Dictionary(data_lemma)
    #Corpus
    texts = data_lemma
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_pt = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_pt[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_pt[1],
                                              eta = hyper_list_pt[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_pt[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_pt
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_pt.print_topics()
    lenpt2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenpt2):
        pt_list = printtopics2[i][1].split('*')
        pt_list_words = []
        lenptl = len(pt_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = pt_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            pt_list_words.append(t_3)
        topic_label_list.append(pt_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list
    
    #Translate the Topic Label 
    tll_translate = []
    lentll = len(topic_label_list)
    for i in range(0, lentll):
        tll_topic_line = []
        lent_t_l = len(topic_label_list[i])
        for j in range(0, lent_t_l):
            text = topic_label_list[i][j]
            translated = GoogleTranslator(source = "portuguese", to_lang = "english").translate(text=text)
            tll_topic_line.append(translated)
        tll_translate.append(tll_topic_line)
        
    #Topic Label Translated 
    topic_labels_translate = tll_translate
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels_translate))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_pt = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_pt


# In[77]:


#Step 59: Visualization of Topics over Time Portuguese
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_pt(df, hyper_list_pt, counter_tm):
    
    #Split Data into individual topics
    topic_dfs = {}
    topic_label_list = []
    for i in range(0, hyper_list_pt[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors = hyper_list_pt[0]
    
    color = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs.keys():
        plt.plot(topic_dfs[i], color = color[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in Portuguese Topics")
    plt.xlabel("Hour") 
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_PT_Hour_" + str(counter_tm))
    plt.close()

# In[78]:


#####################################################################################################################


# In[79]:


#Step 60: LDA Hyperparameter Finding function for Arabic
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
#https://stackoverflow.com/questions/33229360/gensim-typeerror-doc2bow-expects-an-array-of-unicode-tokens-on-input-not-a-si
def lda_hyperparameter_generating_ar(df_ar, final_stop_words_ar):
    #Remove stops words
    data_words_nostops_hf = stopwords_ar(df_ar['text'], final_stop_words_ar)
    #Create the bigram from the non stop words
    #data_words_bigram_hf = str(bigrams(data_words_nostops_hf))
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    #data_lemma_hf = data_tokenization_ar(data_words_bigram_hf)
    #data_lemma_hf = data_tokenization_ar(data_words_nostops_hf)
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    #id2word_hf = corpora.Dictionary([a.split(' ') for a in data_lemma_hf])
    #id2word_hf = corpora.Dictionary([str(data_lemma_hf).split(' ')])
    #id2word_hf = corpora.Dictionary([str(data_words_bigram_hf).split()])
    id2word_hf = corpora.Dictionary(data_words_nostops_hf)
    #Corpus
    #texts_hf = [str(data_lemma_hf).split(' ')]
    #texts_hf = [str(data_words_bigram_hf).split()]
    texts_hf = data_words_nostops_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_words_nostops_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_ar = pd.DataFrame(model_results)
    
    return mr_ar
    #print(mr_ar)


# In[80]:


#Step 61: Hyper Parameter Defining for Arabic
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_ar(mr_ar):
    #Find the right number of topics
    mr2 = mr_ar.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_ar['Topics'] == top_opt
    mr_to = mr_ar[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_ar = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_ar)
    return hyper_list_ar


# In[81]:


#Step 62: Implement the stopwords, bigrams, and lemma functions Arabic
def build_lda_ar(df_ar, final_stop_words_ar, hyper_list_ar):
    #Remove stops words
    data_words_nostops = stopwords_pt(df_ar['text'], final_stop_words_ar)
    #Create the bigram from the non stop words
    #data_words_bigram = str(bigrams(data_words_nostops))
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    #data_lemma = data_tokenization_ar(data_words_bigram)
    #data_lemma = data_tokenization_ar(data_words_nostops)
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    #id2word = corpora.Dictionary([a.split(' ') for a in data_lemma])
    id2word = corpora.Dictionary(data_words_nostops)
    #Corpus
    texts = data_words_nostops
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_ar = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_ar[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_ar[1],
                                              eta = hyper_list_ar[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_ar[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_ar
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_ar.print_topics()
    lenar2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenar2):
        ar_list = printtopics2[i][1].split('*')
        ar_list_words = []
        lenarl = len(ar_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = ar_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            ar_list_words.append(t_3)
        topic_label_list.append(ar_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list
    
    #Translate the Topic Label 
    tll_translate = []
    lentll = len(topic_label_list)
    for i in range(0, lentll):
        tll_topic_line = []
        lent_t_l = len(topic_label_list[i])
        for j in range(0, lent_t_l):
            text = topic_label_list[i][j]
            translated = GoogleTranslator(source = "arabic", to_lang = "english").translate(text=text)
            tll_topic_line.append(translated)
        tll_translate.append(tll_topic_line)
        
    #Topic Label Translated 
    topic_labels_translate = tll_translate
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels_translate))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_ar = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_ar


# In[82]:


#Step 63: Visualization of Topics over Time Arabic
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_ar(df, hyper_list_ar, counter_tm):
    
    #Split Data into individual topics
    topic_dfs = {}
    topic_label_list = []
    for i in range(0, hyper_list_ar[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors = hyper_list_ar[0]
    
    color = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs.keys():
        plt.plot(topic_dfs[i], color = color[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in Arabic Topics")
    plt.xlabel("Hour") 
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_AR_Hour_" + str(counter_tm))
    plt.close()

# In[83]:


######################################################################################################################


# In[84]:


#Step 64: LDA Hyperparameter Finding function for Japanese
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
def lda_hyperparameter_generating_ja(df_ja, final_stop_words_ja):
    #Remove stops words
    data_words_nostops_hf = stopwords_ja(df_ja['text'], final_stop_words_ja)
    #Create the bigram from the non stop words
    data_words_bigram_hf = bigrams(data_words_nostops_hf)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma_hf = data_lemmatization_ja(data_words_bigram_hf, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word_hf = corpora.Dictionary(data_lemma_hf)
    #Corpus
    texts_hf = data_lemma_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_lemma_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_ja = pd.DataFrame(model_results)
    
    return mr_ja


# In[213]:


#Step 65: Hyper Parameter Defining for Japanese
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_ja(mr_ja):
    #Find the right number of topics
    mr2 = mr_ja.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    #print(mr3)
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_ja['Topics'] == top_opt
    mr_to = mr_ja[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_ja = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_ja)
    return hyper_list_ja


# In[86]:


#Step 66: Implement the stopwords, bigrams, and lemma functions Japanese
def build_lda_ja(df_ja, final_stop_words_ja, hyper_list_ja):
    #Remove stops words
    data_words_nostops = stopwords_ja(df_ja['text'], final_stop_words_ja)
    #Create the bigram from the non stop words
    data_words_bigram = bigrams(data_words_nostops)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    data_lemma = data_lemmatization_ja(data_words_bigram, allowed_postags = ["NOUN", "ADJ", "VERB", "ADV"])
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word = corpora.Dictionary(data_lemma)
    #Corpus
    texts = data_lemma
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_ja = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_ja[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_ja[1],
                                              eta = hyper_list_ja[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_ja[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_ja
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_ja.print_topics()
    lenja2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenja2):
        ja_list = printtopics2[i][1].split('*')
        ja_list_words = []
        lenjal = len(ja_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = ja_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            ja_list_words.append(t_3)
        topic_label_list.append(ja_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list
    
    #Translate the Topic Label 
    tll_translate = []
    lentll = len(topic_label_list)
    for i in range(0, lentll):
        tll_topic_line = []
        lent_t_l = len(topic_label_list[i])
        for j in range(0, lent_t_l):
            text = topic_label_list[i][j]
            translated = GoogleTranslator(source = "japanese", to_lang = "english").translate(text=text)
            tll_topic_line.append(translated)
        tll_translate.append(tll_topic_line)
        
    #Topic Label Translated 
    topic_labels_translate = tll_translate
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels_translate))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_ja = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_ja


# In[87]:


#Step 67: Visualization of Topics over Time Japanese
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_ja(df, hyper_list_ja, counter_tm):
    
    #Split Data into individual topics
    topic_dfs = {}
    topic_label_list = []
    for i in range(0, hyper_list_ja[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors = hyper_list_ja[0]
    
    color = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs.keys():
        plt.plot(topic_dfs[i], color = color[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in Japanese Topics")
    plt.xlabel("Hour") 
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_JA_Hour_" + str(counter_tm))
    plt.close()

# In[88]:


#####################################################################################################################


# In[204]:


#Step 64: LDA Hyperparameter Finding function for Korean
#https://stackoverflow.com/questions/60087463/valueerror-stop-argument-for-islice-must-be-none-or-an-integer-0-x-sys
def lda_hyperparameter_generating_ko(df_ko, final_stop_words_ko):
    #Remove stops words
    data_words_nostops_hf = stopwords_ko(df_ko['text'], final_stop_words_ko)
    #Create the bigram from the non stop words
    #data_words_bigram_hf = bigrams(data_words_nostops_hf)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    #data_lemma_hf = data_lemmatization_ko(data_words_bigram_hf)
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    id2word_hf = corpora.Dictionary(data_words_nostops_hf)
    #id2word_hf = corpora.Dictionary([str(data_lemma_hf).split(' ')])
    #Corpus
    #texts_hf = [str(data_lemma_hf).split(' ')]
    texts_hf = data_words_nostops_hf
    #Term Document Matrix
    corpus_hf = [id2word_hf.doc2bow(text) for text in texts_hf]
    
    #Lets iterate over the function to find the optimal number for each of the hyper parameters
    grid_hf = {}
    grid_hf['Validation_Set'] = {}
    
    #Topic Range
    min_topics = 6
    max_topics = 8
    step_size = 1
    topic_range = range(min_topics, max_topics, step_size)
    
    #Alpha Parameter
    alpha = list(np.arange(0.01, 1, 0.3))
    alpha.append('symmetric')
    alpha.append('asymmetric')
    
    #Beta Parameter
    beta = list(np.arange(0.01, 1, 0.3))
    beta.append('symmetric')
    
    #Validation sets
    num_of_docs = len(corpus_hf)
    corpus_sets = [corpus_hf]
    corpus_title = ['100% Corpus']
    model_results = {'Validation_Set': [],
                     'Topics': [],
                     'Alpha': [],
                     'Beta': [],
                     'Coherence': []
                    }
    
    #iterate through validation corpora:
    for i in range(len(corpus_sets)):
        #iterate through number of topics:
        for k in topic_range:
            #iterate through alpha values:
            for a in alpha:
                #iterate through beta values:
                for b in beta:
                    #Get the coherence scores for the given hyperparameters
                    cv = compute_coherence_values(corpus = corpus_sets[i], texts = data_words_nostops_hf,
                                                  dictionary = id2word_hf, k = k, 
                                                  a = a, b = b)
                    #Save the Model Results 
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
    #Look at model results
    mr_ko = pd.DataFrame(model_results)
    
    return mr_ko


# In[205]:


#Step 65: Hyper Parameter Defining for Japanese
#https://stackoverflow.com/questions/20067636/pandas-dataframe-get-first-row-of-each-group
#https://stackoverflow.com/questions/10202570/find-row-where-values-for-column-is-maximal-in-a-pandas-dataframe
#https://stackoverflow.com/questions/15705630/get-the-rows-which-have-the-max-value-in-groups-using-groupby
#https://stackoverflow.com/questions/43193880/how-to-get-row-number-in-dataframe-in-pandas

def lda_hyper_define_ko(mr_ko):
    #Find the right number of topics
    mr2 = mr_ko.groupby("Topics").max().reset_index()
    #Find the number of topics with the highest coherence
    max_coherence = mr2['Coherence'].max()
    mr3_5 = mr2.loc[mr2['Coherence'] == max_coherence]
    mr3 = mr3_5.reset_index(drop = True)
    #Get the Number of Topics for the highest coherence
    top_opt = mr3["Topics"][0]
    #Get the full data set of only the optimal number of topics
    mr_top_opt = mr_ko['Topics'] == top_opt
    mr_to = mr_ko[mr_top_opt]
    mr_to_2 = mr_to.reset_index(drop = True)
    #Get the hyperparameters for alpha and eta from mr_to_2 based on max coherence
    max_co_2 = mr_to_2['Coherence'].max()
    mr_to_3_5 = mr_to_2.loc[mr_to_2['Coherence'] == max_co_2]
    mr_to_3 = mr_to_3_5.reset_index(drop = True)
    #Convert mr_to_3, the optimal hyperparameters to a list 
    hyper_list_ko = [mr_to_3["Topics"][0], mr_to_3["Alpha"][0], mr_to_3["Beta"][0]]
    print(hyper_list_ko)
    return hyper_list_ko


# In[206]:


#Step 66: Implement the stopwords, bigrams, and lemma functions Japanese
def build_lda_ko(df_ko, final_stop_words_ko, hyper_list_ko):
    #Remove stops words
    data_words_nostops = stopwords_ko(df_ko['text'], final_stop_words_ko)
    #Create the bigram from the non stop words
    #data_words_bigram = bigrams(data_words_nostops)
    #Do lemmatization keeping only noun, adj, vb, adv, the lemmatization cuts off the ends of words so they can be
    #grouped an analyze better
    #data_lemma = data_lemmatization_ko(data_words_bigram)
    #Create the dictionary, corpus, and term document matrix
    #Dictionary
    #id2word = corpora.Dictionary([str(data_lemma).split(' ')])
    id2word = corpora.Dictionary(data_words_nostops)
    #Corpus
    texts = data_words_nostops
    #Term Document Matrix
    corpus = [id2word.doc2bow(text) for text in texts]
    #Train the actual LDA model
    #Watch out for too many topics
    lda_model_ko = gensim.models.LdaMulticore(corpus = corpus,
                                              id2word = id2word,
                                              num_topics = hyper_list_ko[0],
                                              random_state = 105,
                                              chunksize = 100,
                                              passes = 10,
                                              alpha = hyper_list_ko[1],
                                              eta = hyper_list_ko[2],
                                              per_word_topics = True,
                                              minimum_probability = 0)
    
    #Create the weights dataframe
    #Extract individual document topic proportions as determined by the LDA model. Our Gensim LDA model can classify 
    #the specific relative proportions for all ten topics within each document as long as you set the minimum_probability
    #argument to 0. If you did not do this, then some topics may be dropped from the final weighting if they did not 
    #meet the probability threshold set by default.
    weights_output = pd.DataFrame(columns = ['topic', 'prob_weight', 'doc_id'])
    
    #Extraction Loop: This loop extracts the topic proportions for all five topics for every individual document and
    #places them into a dataframe with a document-id key for merging topic proportion information with other datasets
    #about our corpus
    for i in range(0, len(corpus)):
        doc_weights = lda_model_ko[corpus[i]][0]
        weights_df = pd.DataFrame(list(doc_weights), columns = ['topic', 'prob_weight'])
        weights_df['doc_id'] = i
        weights_output = weights_output.append(weights_df)
    
    #Create the daily (or hourly) weights data
    df2 = df_ko
    df = weights_output
    
    #Create new dataset from the speechs with doc_id
    df3 = df2.reset_index()
    df3['doc_id'] = df3.index
    
    #Merge the Two Dataframe Together
    df4 = pd.merge(df, df3[['doc_id', 'Date', 'Year', 'Month', 'Day', 'Hour', 'Minute', 'Second', 'text']], on = 'doc_id', how = 'left')
    
    #Get the count of the total documents by Minute
    # This should be changed to Hour if I decide to do a full day of tweets instead
    total_docs = df4.groupby('Hour')['doc_id'].apply(lambda x: len(x.unique())).reset_index()
    
    #Label total_docs columns
    total_docs.columns = ['Hour', 'total_docs']
    
    #Get the Probability weight per Month and Topic 
    df_avg = df4.groupby(['Hour', 'topic']).agg({'prob_weight': 'sum'}).reset_index()
    
    #Combine the prob_weight and the total_docs data frames
    df_avg2 = df_avg.merge(total_docs, on = 'Hour', how = 'left')
    
    #Create the Average Weight of each Day and Topic
    df_avg2['average_weight'] = df_avg2['prob_weight'] / df_avg2['total_docs']
    
    #Get the Keywords from each Topics from the LDA Topic and Automatically Label them
    printtopics2 = lda_model_ko.print_topics()
    lenko2 = len(printtopics2)
    topic_label_list = []
    #For All the topics in generated by the model
    for i in range(0, lenko2):
        ko_list = printtopics2[i][1].split('*')
        ko_list_words = []
        lenkol = len(ko_list)
        #Split the string list in the loop to get the first 5 topic words
        for j in range(1, 6):
            t_1 = ko_list[j]
            t_2 = t_1.split('+')
            t_3 = t_2[0]
            ko_list_words.append(t_3)
        topic_label_list.append(ko_list_words)
        
    #Set the Topic Labels to topic_label_list
    topic_labels = topic_label_list

    #Output the Korean Topics Untranslated to see if the translation is improved manually
    korean_topic_df = pd.DataFrame(topic_labels, columns = ["Korean_Topic_Labels", "Column2", "Column3", "Column4", "Column5"])
    korean_topic_df.to_csv("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Korean_Topics_Untranslated.csv")

    #Translate the Topic Label 
    tll_translate = []
    lentll = len(topic_label_list)
    for i in range(0, lentll):
        tll_topic_line = []
        lent_t_l = len(topic_label_list[i])
        for j in range(0, lent_t_l):
            text = topic_label_list[i][j]
            translated = GoogleTranslator(source = "korean", to_lang = "english").translate(text=text)
            tll_topic_line.append(translated)
        tll_translate.append(tll_topic_line)
        
    #Topic Label Translated 
    topic_labels_translate = tll_translate
    
    #Create topic_id numbers based on the createList function
    lenpt3 = len(printtopics2)
    topic_id = createList(lenpt3)
    
    #Combine the topic_id and topic_label
    data_tuple = list(zip(topic_id, topic_labels_translate))
    
    #Convert into a dataframe
    df_labels = pd.DataFrame(data_tuple, columns = ['topic', 'topic_label'])
    
    #Merge labels into year weights data
    df_avg3 = df_avg2.merge(df_labels, on = 'topic')
    
    #Create the final per-document dataframe for broader analysis
    #Make sure to change on = ["Minute"] if want to use a different time scale
    df11_ko = pd.merge(df4, df_avg3[['Hour', 'topic', 'average_weight', 'total_docs', 'topic_label']], 
                    on = ['Hour', 'topic'], how = 'left')
    
    return df11_ko


# In[207]:


#Step 67: Visualization of Topics over Time Japanese
#https://stackoverflow.com/questions/9622163/save-plot-to-image-file-instead-of-displaying-it-using-matplotlib
#https://stackoverflow.com/questions/12560600/creating-a-new-file-filename-contains-loop-variable-python
#https://stackoverflow.com/questions/33907776/how-to-create-an-array-of-dataframes-in-python
def viz_topic_time_ko(df, hyper_list_ko, counter_tm):
    
    #Split Data into individual topics
    topic_dfs = {}
    topic_label_list = []
    for i in range(0, hyper_list_ko[0]):
        df_1_5 = df[df["topic"] == i]
        df_1 = df_1_5.reset_index(drop = True)
        topic_label_list.append(df_1["topic_label"][0])
        topic_plots = df_1.groupby("Hour")["average_weight"].mean()
        topic_dfs[i] = topic_plots
  
    #Change the size of the Plot
    plt.rcParams['figure.figsize'] = [20, 14]
    
    #Get the colors for the lines
    num_colors = hyper_list_ko[0]
    
    color = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])
                for i in range(0, num_colors)]
    
    #Create the plot
    #Change Legends based on Topic Labels, Plot the topic changes over time and colors
    for i in topic_dfs.keys():
        plt.plot(topic_dfs[i], color = color[i])
    plt.xlim(14, 20)
    plt.ylim(0, 1)
    plt.axhline(df['average_weight'].median(), color = "black")
    plt.title("Change in Korean Topics")
    plt.xlabel("Hour")
    plt.ylabel("Average Hour Topic Weight")
    plt.legend((topic_label_list))
    plt.grid()
    plt.savefig("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Topic_Model_Charts/Test_Output_KO_Hour_" + str(counter_tm))
    plt.close()

# In[208]:


#####################################################################################################################


# In[216]:


#Part 54: The Main Function
def main_tm(counter_tm):
    tmfull = all_files(path_to_json)
    tmfull2 = lang_loop(tmfull)
    tmfull3 = date_func(tmfull2)
    tmfull4 = year_func(tmfull3)
    tmfull5 = month_func(tmfull4)
    tmfull6 = day_func(tmfull5)
    tmfull7 = hour_func(tmfull6)
    tmfull8 = minute_func(tmfull7)
    tmfull9 = second_func(tmfull8)
    tmfull10 = date_combos(tmfull9)
    eng_tweet = English_Tweets_Func(tmfull10)
    esp_tweet = Spanish_Tweets_Func(tmfull10)
    frn_tweet = French_Tweets_Func(tmfull10)
    prt_tweet = Portuguese_Tweets_Func(tmfull10)
    arb_tweet = Arabic_Tweets_Func(tmfull10)
    jpn_tweet = Japanese_Tweets_Func(tmfull10)
    kor_tweet = Korean_Tweets_Func(tmfull10)
    eng_t2 = sort_chrono(eng_tweet)
    esp_t2 = sort_chrono(esp_tweet)
    frn_t2 = sort_chrono(frn_tweet)
    prt_t2 = sort_chrono(prt_tweet)
    arb_t2 = sort_chrono(arb_tweet)
    jpn_t2 = sort_chrono(jpn_tweet)
    kor_t2 = sort_chrono(kor_tweet)
    final_stop_words_en = stopwords_en_func()
    final_stop_words_sp = stopwords_sp_func()
    final_stop_words_fr = stopwords_fr_func()
    final_stop_words_pt = stopwords_pt_func()
    final_stop_words_ar = stopwords_ar_func()
    final_stop_words_ja = stopwords_ja_func()
    final_stop_words_ko = stopwords_ko_func()
    mr_en = lda_hyperparameter_generating_en(eng_t2, final_stop_words_en)
    mr_sp = lda_hyperparameter_generating_sp(esp_t2, final_stop_words_sp)
    mr_fr = lda_hyperparameter_generating_fr(frn_t2, final_stop_words_fr)
    mr_pt = lda_hyperparameter_generating_pt(prt_t2, final_stop_words_pt)
    mr_ar = lda_hyperparameter_generating_ar(arb_t2, final_stop_words_ar)
    mr_ja = lda_hyperparameter_generating_ja(jpn_t2, final_stop_words_ja)
    mr_ko = lda_hyperparameter_generating_ko(kor_t2, final_stop_words_ko)
    hyper_list_en = lda_hyper_define_en(mr_en)
    hyper_list_sp = lda_hyper_define_sp(mr_sp)
    hyper_list_fr = lda_hyper_define_fr(mr_fr)
    hyper_list_pt = lda_hyper_define_pt(mr_pt)
    hyper_list_ar = lda_hyper_define_ar(mr_ar)
    hyper_list_ja = lda_hyper_define_ja(mr_ja)
    hyper_list_ko = lda_hyper_define_ko(mr_ko)
    en_tm_final = build_lda_en(eng_t2, final_stop_words_en, hyper_list_en)
    sp_tm_final = build_lda_sp(esp_t2, final_stop_words_sp, hyper_list_sp)
    fr_tm_final = build_lda_fr(frn_t2, final_stop_words_fr, hyper_list_fr)
    pt_tm_final = build_lda_pt(prt_t2, final_stop_words_pt, hyper_list_pt)
    ar_tm_final = build_lda_ar(arb_t2, final_stop_words_ar, hyper_list_ar)
    ja_tm_final = build_lda_ja(jpn_t2, final_stop_words_ja, hyper_list_ja)
    ko_tm_final = build_lda_ko(kor_t2, final_stop_words_ko, hyper_list_ko)
    viz_topic_time_en(en_tm_final, hyper_list_en, counter_tm)
    viz_topic_time_sp(sp_tm_final, hyper_list_sp, counter_tm)
    viz_topic_time_fr(fr_tm_final, hyper_list_fr, counter_tm)
    viz_topic_time_pt(pt_tm_final, hyper_list_pt, counter_tm)
    viz_topic_time_ar(ar_tm_final, hyper_list_ar, counter_tm)
    viz_topic_time_ja(ja_tm_final, hyper_list_ja, counter_tm)
    viz_topic_time_ko(ko_tm_final, hyper_list_ko, counter_tm)
    counter_tm = counter_tm + 1

# In[1]:


#Step 5: Add the Runner 
#Add a Counter Token somewhere in the loop
#if __name__ == "__main__":
#    while(True):
#        main_tm(counter_tm)
#        counter_tm = counter_tm + 1
#        time.sleep(10)


# In[ ]:





# In[ ]:


#####################################################################################################################


# In[ ]:





# In[ ]:





# In[ ]:





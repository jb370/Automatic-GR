#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#The Main function fix for the analysis for My Paper 5
#Make sure to keep the copies of the functions with the mapping Google API parts at the bottom and create a second 
#main function, so it can be called to create maps when needed


# In[ ]:


#Step 0: Libraries


# In[ ]:


#Part 1: All Libraries from the top
import requests
import os
import json
import socket
import sys
import errno
import time
import sys
import pandas as pd
from io import StringIO
import numpy as np


# In[ ]:


#Part 2: Libraries for the getting the latest file
import glob
import os.path


# In[ ]:


#Part 3: Libraries to get the time of when the batch is imported 
#https://www.programiz.com/python-programming/datetime/current-datetime
from datetime import datetime


# In[ ]:


#Part 4: Libraries for Language Detection
#Tag the languages with langdetect
#Since the package is non-deterministic, and we are dealing with short texts, we might get a different result 
#each time it is run so we need to do Step 1
#Enforce consistent results 
from langdetect import DetectorFactory
#Import the detect function
from langdetect import detect


# In[ ]:


#Part 5: English Analysis Libraries needed:
import nltk
nltk.download('punkt')
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer
sentianalyzer = SentimentIntensityAnalyzer()
#This time we will add the individual sentiment to the tweet
from nltk.tokenize import sent_tokenize


# In[ ]:


#Part 5.5: NER and Google Mapping Functions
import spacy
import googlemaps
gmaps = googlemaps.Client(key = xxxxxxxxxxxxxxxx)


# In[ ]:


#Part 6: Spanish Anaysis Libraries Needed:
from sklearn.model_selection import train_test_split
import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_text as tf_text
from tensorflow import keras
from tensorflow.keras import layers
import joblib


# In[ ]:


#Part 7: French Libraries Needed
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split


# In[ ]:


#Part 8: Portuguese Libraries Needed
#import csv
#import re
#Import Portuguese Stop Words
#https://stackoverflow.com/questions/54573853/nltk-available-languages-for-stopwords
#import nltk
#from nltk.corpus import stopwords
#portuguese_stopwords = stopwords.words('portuguese')
#Import Tokenizer
#from nltk import tokenize


# In[ ]:


#Part 9: Arabic Libraries Needed
from transformers import pipeline


# In[ ]:


#Part 10: Japanese Libraries Needed
import csv


# In[ ]:


#Part 11: Korean Libraries Needed
from transformers import pipeline
import numpy as np
import csv
#Import konlpy
from konlpy.tag import Okt
from konlpy.utils import pprint


# In[ ]:


#Part 12: Library needed to append the new data file to the existing csv
from csv import writer


# In[ ]:


#Part 13: Library Create a map with Folium
#http://python-visualization.github.io/folium/quickstart.html#Getting-Started
import folium


# In[ ]:


#Step 14: Library needed to translate the locations to English
from deep_translator import GoogleTranslator


# In[ ]:





# In[ ]:


#Step 1: The constant variables


# In[ ]:


#Part 1: Importing the latest files constant variables
folder_path = r'/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/json_file/'
#folder_path will need to be changed
file_type = r'/*.json'


# In[ ]:


#Part 2: Enforcing consistent results for the Language Detection constant variables
DetectorFactory.seed = 0


# In[ ]:


#Part 3: Import RNN Spanish Model #GET CORRECT SPANISH MODEL
RNN_sp_model = joblib.load('/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/RNN_Spanish_2tass.joblib')
RNN_sp_model.summary()


# In[ ]:


#Part 4: Import the French RNN Model
RNN_fr_model = joblib.load('/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/RNN_French_1.joblib')
RNN_fr_model.summary()


# In[ ]:


#Part 5: Import Portuguese RNN Model
RNN_pt_model = joblib.load('/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/RNN_pt_2.joblib')
RNN_pt_model.summary()


# In[ ]:


#Part 6: Import the Arabic Sentiment Analysis Hugging Face Model
#https://huggingface.co/CAMeL-Lab/bert-base-arabic-camelbert-mix-sentiment
sa_ar = pipeline("sentiment-analysis", model = 'CAMeL-Lab/bert-base-arabic-camelbert-mix-sentiment')


# In[ ]:


#Part 7: NER Arabic Hugging Face Model
#https://huggingface.co/hatmimoha/arabic-ner
#https://github.com/hatmimoha/arabic-ner
nlp_ar_2 = pipeline("ner", model = 'hatmimoha/arabic-ner')


# In[ ]:


#Part 8: Import RNN Japanese Model
RNN_ja_model = joblib.load('/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/RNN_Japanese_1.joblib')
RNN_ja_model.summary()


# In[ ]:


#Step 9: Import RNN Korean Model
RNN_ko_model = joblib.load('/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 7/Twitter Language Samples/Korean/Korean RNN Test/RNN_ko.joblib')
RNN_ko_model.summary()


# In[ ]:


#Part 10: Import the Korean World Data Set
df_ko_world = pd.read_csv("/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/Ko_World_Token.csv")
df_ko_world.head()


# In[ ]:


#Part 12: Define the okt function from KoNLPy
okt = Okt()


# In[ ]:


#Part 13: Create list of topics
topic_list = ["Goldstein Negative", "Goldstein Positive", "Nuclear Threat", 
                    "Cyber Warfare", "War Threats", "Oil Supply Shock", 
                    "US-China Relations", "Terrorism", "Geopolitical Risks"]


# In[ ]:


#Part 13.5: Create list of languages
lang_list = ["en", "es", "fr", "pt", "ar", "ja", "ko"]


# In[ ]:


#Step 14: Import Country - Production Excel File
country_product = pd.read_excel("/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/continents2.xls")
country_product_2 = country_product.rename(columns = {"name":"textloc_en"})


# In[ ]:


#Step 15: Import Topic - Industry Excel File
Topic_Product = pd.read_excel("/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/Topic_Industry.xlsx")
Topic_Product_2 = Topic_Product.rename(columns = {"Topic_Label":"tag"})


# In[ ]:


#Step 16: Import the Topic - Financial Data
Topic_Finance = pd.read_excel("/Users/johnc.burns/Documents/Documents/PhD Year Two/Mockup 8/Topic_Financial.xlsx")
Topic_Finance_2 = Topic_Finance.rename(columns = {"Topic_Label":"Topics"})


# In[ ]:


#Step 17: Counter Token
counter_2 = 0


# In[ ]:





# In[ ]:


#Step 2: Writing the Functions


# In[ ]:


#Part 1: Importing the latest files Function
def latest_file(folder_path, file_type, counter_2):
    #First: get the file from the folder and output it to a dataframe and then return that data frame in the end
    files = glob.glob(folder_path + file_type)
    max_file = max(files, key = os.path.getctime)
    df = pd.read_json(max_file)
    mf_str = str(max_file)
    mf_name = mf_str[-17:]
    print(mf_name)
    #Second: Clean the data removing the id and text and replacing them with pseudo variables and output that file to a new folder
    df_clean = df.reset_index()
    df_clean = df_clean.rename(columns = {"index":"id_new"})
    df_clean = df_clean.drop(columns = ["id", "edit_history_tweet_ids"], axis = 1)
    df_clean = df_clean.rename(columns = {"id_new": "id"})
    df_clean["text_pseudo"] = ""
    lendfclean = len(df_clean["id"])
    for i in range(0, lendfclean):
        dfclean_id_str = str(df_clean["id"][i])
        c2_str = str(counter_2)
        dfclean_tp = c2_str + dfclean_id_str
        df_clean["text_pseudo"][i] = dfclean_tp
    df_clean = df_clean.drop(columns = ["text"], axis = 1)
    #Output clean data to json and folder
    #df_clean.to_json(f'/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Clean_Jsons/json_clean_{counter_2}.json')
    df_clean.to_json(f'/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Clean_Jsons/json_clean_{mf_name}')
    #Return the dataframe to continue the analysis
    return df


# In[ ]:


#Part 1.5: Get the name of the latest file
def name_latest_file(folder_path, file_type):
    #Get the file from the folder and output the name of the folder
    files2 = glob.glob(folder_path + file_type)
    max_file2 = max(files2, key = os.path.getctime)
    mf_str2 = str(max_file2)
    mf_name2 = mf_str2[-17:]
    return mf_name2


# In[ ]:


#Part 2: Getting the current date and time Function
def datetimenow():
    now = datetime.now()
    d = now.strftime("%d/%m/%Y %H:%M:%S")
    return d


# In[ ]:


#Part 3: Language detect Function
def lang_detect_2(text):
    detectanswer = detect(text)
    return detectanswer


# In[ ]:


#Part 4: Set up the language detection loop Function
def lang_loop(df):
    #Get Length of dataframe
    lendf = len(df)
    #Create new column with string
    df['lang'] = ""
    #Use the language Detect function to get the language of the text
    for i in range(0, lendf):
        try:
            df["lang"][i] = lang_detect_2(df["text"][i])
        except:
            df["lang"][i] = "und"
            
    return df


# In[ ]:


#Part 5: Word Count Function
def word_count(df):
    #New Column for Word Count
    #df["wordcount"] = df["text"].str.split().str.len()
    #Select Rows based on Column values
    #df_gt = df.loc[df['wordcount'] > 10]
    df_gt = df
    return df_gt


# In[ ]:





# In[ ]:


#Break into different languages functions


# In[ ]:


#Part 6: Break into English Tweets
def English_Tweets_Func(df_gt):
    English_Tweets = df_gt[df_gt['lang'] == "en"]
    English_Tweets.reset_index(drop = True, inplace = True)
    English_Tweets['TweetNumber'] = np.arange(len(English_Tweets))
    return English_Tweets


# In[ ]:


#Part 7: Break into Spanish Tweets
def Spanish_Tweets_Func(df_gt):
    Spanish_Tweets = df_gt[df_gt['lang'] == "es"]
    Spanish_Tweets.reset_index(drop = True, inplace = True)
    Spanish_Tweets['TweetNumber'] = np.arange(len(Spanish_Tweets))
    return Spanish_Tweets


# In[ ]:


#Part 8: Break into French Tweets
def French_Tweets_Func(df_gt):
    French_Tweets = df_gt[df_gt['lang'] == "fr"]
    French_Tweets.reset_index(drop = True, inplace = True)
    French_Tweets['TweetNumber'] = np.arange(len(French_Tweets))
    return French_Tweets


# In[ ]:


#Part 9: Break into Portuguese Tweets
def Portuguese_Tweets_Func(df_gt):
    Portuguese_Tweets = df_gt[df_gt['lang'] == "pt"]
    Portuguese_Tweets.reset_index(drop = True, inplace = True)
    Portuguese_Tweets['TweetNumber'] = np.arange(len(Portuguese_Tweets))
    return Portuguese_Tweets


# In[ ]:


#Part 10: Break into Arabic Tweets
def Arabic_Tweets_Func(df_gt):
    Arabic_Tweets = df_gt[df_gt['lang'] == "ar"]
    Arabic_Tweets.reset_index(drop = True, inplace = True)
    Arabic_Tweets['TweetNumber'] = np.arange(len(Arabic_Tweets))
    return Arabic_Tweets


# In[ ]:


#Part 11: Break into Japanese Tweets
def Japanese_Tweets_Func(df_gt):
    Japanese_Tweets = df_gt[df_gt['lang'] == "ja"]
    Japanese_Tweets.reset_index(drop = True, inplace = True)
    Japanese_Tweets['TweetNumber'] = np.arange(len(Japanese_Tweets)) 
    return Japanese_Tweets


# In[ ]:


#Part 12: Break into Korean Tweets
def Korean_Tweets_Func(df_gt):
    Korean_Tweets = df_gt[df_gt['lang'] == "ko"]
    Korean_Tweets.reset_index(drop = True, inplace = True)
    Korean_Tweets['TweetNumber'] = np.arange(len(Korean_Tweets))
    return Korean_Tweets


# In[ ]:





# In[ ]:


#Language Analysis Functions


# In[ ]:


def english_analysis(df):
    #Length of the English Tweets
    LenEnT = len(df.index)
    LenEnT

    #Create a new dataframe
    EnTCompound = pd.DataFrame([])
    EnTSentence = pd.DataFrame([])

    #This loop takes the contents from each article, tokenizes each sentence in the article, counts the number of 
    #sentences in the article and then gets the sentiments of each sentence and exports those sentiments to a dataframe
    for i in np.arange(0, LenEnT):
        dtestent = df["text"][i]
        dictionary = sentianalyzer.polarity_scores(dtestent)
        c1 = dictionary.get('compound')
        EnTCompound = EnTCompound.append(pd.DataFrame({'Compound': c1}, index = [0]), ignore_index = True)
    
    #Add the Sentiment to the DataFrame
    frames = [df, EnTCompound]
    finalent = pd.concat(frames, axis = 1)
    
    #Normalize the Sentiment
    #1. Conditions
    conditions_eng = [
        (finalent['Compound'] <= -0.25),
        (finalent['Compound'] > -0.25) & (finalent['Compound'] < 0.25),
        (finalent['Compound'] >= 0.25)
    ]
    
    #2. Values
    values_eng = [-1, 0, 1]
    
    #3. New Variable
    finalent['Sentiment'] = np.select(conditions_eng, values_eng)
    
    #Matching Patterns for countries for GeoCoding
    lenentw = len(finalent["text"])

    #Create a new dataframe
    ettext = pd.DataFrame([])
    etlabel = pd.DataFrame([])
    ettweet = pd.DataFrame([])

    #Initialize the NLP in Spacy
    nlp = spacy.load("en_core_web_sm")
    for i in np.arange(0, lenentw):
        etspacy = finalent["text"][i]
        doc = nlp(etspacy)
        for ent in doc.ents:
            ettext = ettext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            etlabel = etlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            ettweet = ettweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Combining the Spacy Findings
    frames_spacy = [ettweet, ettext, etlabel]
    finalent_spacy = pd.concat(frames_spacy, axis = 1)
    
    #Keep only the GPE entities
    gpedf = finalent_spacy[finalent_spacy['label'] == "GPE"]
    
    #Left Merge Back the GPE labels to the tweets
    etlocations = pd.merge(finalent, gpedf, on = "TweetNumber", how = "left")

    #Left Merge The Lat and Long into to the tweets
    etcoord = etlocations
    return etcoord


# In[ ]:


#Part 14: Spanish Convert Sentiment Results to -1, 1 
#CHANGE THE CONVERSION RULES
def convert_sp(df, i):
    if (df["results"][i][0]) > 0.935:
        return 1
    else:
        return -1


# In[ ]:


#Part 15: THIS IS THE SPANISH ANALYSIS FUNCTION
#https://stackoverflow.com/questions/38895768/python-pandas-dataframe-is-it-pass-by-value-or-pass-by-reference
def spanish_analysis(df):
    
    #Part 1: Sentiment Analysis with Spanish RNN
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    
    twsp_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data
    batch_size = 2
    twsp_ran_set = twsp_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twsp_predict = RNN_sp_model.predict(twsp_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twsp_predict.tolist()
    
    #Step 5: Convert Results to -1, 1
    lendtt = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendtt):
        df["Sentiment"][i] = convert_sp(df, i)
    
    
    #Part 2: Get the NER, Location Text, and Coordinates 
    
    #Get the length of the finalspt dataframe
    lensptw = len(df["text"])

    #First: Create the new dataframes to capture the different NER parts
    spttext = pd.DataFrame([])
    sptlabel = pd.DataFrame([])
    spttweet = pd.DataFrame([])

    #Second: Initialize the NLP in Spacy
    nlp = spacy.load("es_core_news_sm")
    for i in np.arange(0, lensptw):
        sptspacy = df["text"][i]
        doc_sp = nlp(sptspacy)
        for ent in doc_sp.ents:
            spttext = spttext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            sptlabel = sptlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            spttweet = spttweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Third: Combining the Spacy Spanish Findings
    frames_spacy_sp = [spttweet, spttext, sptlabel]
    finalent_spacy_sp = pd.concat(frames_spacy_sp, axis = 1)
    
    #Fourth: Keep only the GPE parts 
    gpedf_sp = finalent_spacy_sp[finalent_spacy_sp['label'] == "LOC"]
    
    #Fifth: Merge the GPE on the Main Data Frame
    sptlocations = pd.merge(df, gpedf_sp, on = "TweetNumber", how = "left")
    
    #Left Merge The Lat and Long into to the tweets
    sptcoord = sptlocations
    return sptcoord


# In[ ]:


#Part 16: French Convert Results to -1, 1
def convert_fr(df, i):
    if (df["results"][i][0]) > 0.5:
        return 1
    else:
        return -1


# In[ ]:


#Part 17: French Analysis Function Update
def french_analysis(df):
    
    #Part 1: Sentiment Analysis
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twfr_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 128
    twfr_ran_set = twfr_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twfr_predict = RNN_fr_model.predict(twfr_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twfr_predict.tolist()
    
    #Step 5: Convert Results to -1, 1
    lendfr = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendfr):
        df["Sentiment"][i] = convert_fr(df, i)
    
    #Part 2: Get the NER, Location Text, and Coordinates, 
    
    #Step 4: Put the Index Number as Tweet Number
    #https://stackoverflow.com/questions/20461165/how-to-convert-index-of-a-pandas-dataframe-into-a-column
    df["TweetNumber"] = df.index
    
    #Step 5: NER Spacy for French 
    lendfr2 = len(df["text"])

    #Create a new dataframe
    frtext = pd.DataFrame([])
    frlabel = pd.DataFrame([])
    frtweet = pd.DataFrame([])

    #Initialize the NLP in Spacy
    nlp_fr_sp = spacy.load("fr_core_news_sm")
    for i in np.arange(0, lendfr2):
        frspacy = df["text"][i]
        doc = nlp_fr_sp(frspacy)
        for ent in doc.ents:
            frtext = frtext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            frlabel = frlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            frtweet = frtweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Step 6: Combining the Spacy Findings
    frames_spacy_fr = [frtweet, frtext, frlabel]
    finalent_spacy_fr = pd.concat(frames_spacy_fr, axis = 1)
    
    #Step 7: Keep only the LOC entities
    gpedf_fr = finalent_spacy_fr[finalent_spacy_fr['label'] == "LOC"]
    
    #Step 8: Left Merge Back the GPE labels to the tweets
    frlocations = pd.merge(df, gpedf_fr, on = "TweetNumber", how = "left")
    
    #Step 12: Left Merge The Lat and Long into to the tweets
    frcoord = frlocations 
    return frcoord


# In[ ]:


#Part 18: Portuguese Convert Sentiment Results to 0, 1
def convert_pt_rnn(df, i):
    if df["results"][i][0] > 0.8:
        return 1
    else:
        return -1


# In[ ]:


#Part 19: Main Portuguese Function
def portuguese_analysis(df):
    
    #Part 1: Sentiment Analysis
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twpt_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 4
    twpt_ran_set = twpt_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twpt_predict = RNN_pt_model.predict(twpt_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twpt_predict.tolist()
    
    #Step 5: Convert Results to 0, 1
    lendtt = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendtt):
        df["Sentiment"][i] = convert_pt_rnn(df, i)
    
    #Part 2: Named Entity Recognition and Geocoding for Coordinates
    
    #Step 1: Length of Dataframe
    lenpttw = len(df["text"])

    #Step 2: Create a new dataframe for Appending
    pttext = pd.DataFrame([])
    ptlabel = pd.DataFrame([])
    pttweet = pd.DataFrame([])

    #Step 3: Initialize the NLP in Spacy
    nlp_pt = spacy.load("pt_core_news_sm")
    for i in np.arange(0, lenpttw):
        ptspacy = df["text"][i]
        doc = nlp_pt(ptspacy)
        for ent in doc.ents:
            pttext = pttext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            ptlabel = ptlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            pttweet = pttweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            
    #Step 4: Combining the Spacy Findings
    frames_spacy_pt = [pttweet, pttext, ptlabel]
    finalpt_spacy = pd.concat(frames_spacy_pt, axis = 1)
    
    #Step 5: Keep only the LOC entities
    gpedf_pt = finalpt_spacy[finalpt_spacy['label'] == "LOC"]
    
    #Step 6: Left Merge Back the GPE labels to the tweets
    ptlocations = pd.merge(df, gpedf_pt, on = "TweetNumber", how = "left")
    
    #Step 10: Left Merge The Lat and Long into to the tweets
    ptcoord = ptlocations
    return ptcoord


# In[ ]:


#Part 20: Arabic Convert Sentiment Results to -1, 0, 1
def convert_ar(df, i):
    if df["Sentiment_label"][i] == "positive":
        return 1
    elif df["Sentiment_label"][i] == "negative":
        return -1
    else:
        return 0


# In[ ]:


#Part 21: Main Arabic Analysis Function
def arabic_analysis(df):
    
    #Part 1: Sentiment Analysis
    
    #Step 1: Use the tranformer to get the sentiment 
    lendar2 = len(df)
    df["Sentiment_label"] = ""
    for i in range(0, lendar2):
        ar_sa_test = sa_ar(df["text"][i])
        df["Sentiment_label"][i] = ar_sa_test[0]['label']
    
    #Step 2: Convert the Results
    df["Sentiment"] = 0
    for i in range(0, lendar2):
        df["Sentiment"][i] = convert_ar(df, i)
            
    #Part 2: Use the Second Tranformer for the NER Locations
    
    #Step 1: Get the list of locations named in tweets
    df["Location"] = ""
    lennat2 = len(df)
    for i in range(0, lennat2):
        named_test1 = nlp_ar_2(df["text"][i])
        if not named_test1:
            df["Location"][i] = "---"
        else:
            entity_list = []
            word_list = []
            for j in range(0, len(named_test1)):
                entity_list.append(named_test1[j]["entity"])
                word_list.append(named_test1[j]["word"])
                entity_index = [m for m, x in enumerate(entity_list) if x == "LABEL_4"]
                location_list = [word_list[k] for k in entity_index]
            df["Location"][i] = location_list
            
    #Step 2: Get a Single Location
    #This might be changed in the future if I can make multiple copies of a tweet for each location
    df["textloc"] = ""
    for i in range(0, len(df["textloc"])):
        if not df["Location"][i]:
            df["textloc"][i] = "---"
        else:
            single_loc = df["Location"][i][0]
            df["textloc"][i] = single_loc
            
    #Step 3: Drop the All Locations
    df2 = df.drop(["Location"], axis = 1)
    
    #Step 4: Reform the data
    arcoord = df2.reset_index(drop = True)
    return arcoord


# In[ ]:


#Part 22: Convert Japanese Sentiment Analysis Results to 0, 1
def convert_japanese(df, i):
    if (df["results"][i][0]) > 0.5:
        return 1
    else:
        return -1


# In[ ]:


#Part 23: The Main Japanese Function
def japanese_analysis(df):
    
    #Part 1: Sentiment Analysis
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twja_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 32
    twja_ran_set = twja_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twja_predict = RNN_ja_model.predict(twja_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twja_predict.tolist()
    
    #Step 5: Convert Results to -1, 0, 1
    lendttja = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendttja):
        df["Sentiment"][i] = convert_japanese(df, i)
            
    #Part 2: Named Entity Recognition Japanese
    
    #Step 1: Length of Dataframe
    lenjatw = len(df["text"])
    
    #Step 2: Create a new dataframe for Appending
    jatext = pd.DataFrame([])
    jalabel = pd.DataFrame([])
    jatweet = pd.DataFrame([])
    
    #Step 3: Initialize the NLP in Spacy
    nlp_ja = spacy.load("ja_core_news_sm")
    for i in np.arange(0, lenjatw):
        jaspacy = df["text"][i]
        doc = nlp_ja(jaspacy)
        if not doc.ents:
            jatext = jatext.append(pd.DataFrame({'textloc': np.nan}, index = [0]), ignore_index = True)
            jalabel = jalabel.append(pd.DataFrame({'label': np.nan}, index = [0]), ignore_index = True)
            jatweet = jatweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        else:
            for ent in doc.ents:
                jatext = jatext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
                jalabel = jalabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
                jatweet = jatweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            
    #Step 4: Combining the Spacy Findings
    frames_spacy_ja = [jatweet, jatext, jalabel]
    finalja_spacy = pd.concat(frames_spacy_ja, axis = 1)
    
    #Step 5: Keep only the GPE entities
    gpedf_ja = finalja_spacy[finalja_spacy["label"] == "GPE"]
    
    #Step 6: Left Merge Back the GPE labels to the tweets
    jalocations = pd.merge(df, gpedf_ja, on = "TweetNumber", how = "left")
    jacoord = jalocations
    return jacoord


# In[ ]:


#Step 24: Convert Results to 0, 1
def convert_korean(df, i):
    if (df["results"][i][0]) > 0.5:
        return 1
    else:
        return -1


# In[ ]:


#Part 25: Korean Analysis Function
def korean_analysis(df):

    #Part 1: Sentiment Analysis with Korean RNN
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twko_ran = (
        tf.data.Dataset.from_tensor_slices(
            
            (
                tf.cast(df['text'].values, tf.string),
            )
            
            )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 4
    twko_ran_set = twko_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twko_predict = RNN_ko_model.predict(twko_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twko_predict.tolist()
    
    #Step 5: Convert Results to -1, 0, 1
    lendttko = len(df["text"])
    df["Sentiment"] = 0
    for i in range(0, lendttko):
        df["Sentiment"][i] = convert_korean(df, i)
  
    #Part 2: Text Country and Coordinates  from the text
    
    #Step 1: Create the text_country variable
    df["textloc"] = ""
    lenk2test = len(df["textloc"])
    for i in range(0, lenk2test):
        try:
            #Step 2: Get the text
            text_2 = df["text"][i]
            #Step 3: Using Konlpy get the tokenization of the text and 
            #Transform it into a pandas dataframe
            kt_df_2 = pd.DataFrame(okt.morphs(text_2, norm = True, stem = True))
            kt_df_2.columns = ['name']
            #Step 3: Merge the Token DataFrame on the Tokenized Sentiment Lexicon
            token_text_country_test = pd.merge(kt_df_2, df_ko_world, on = "name", how = "inner")
            #Step 4: Get the first token and put in as the text country, not perfect but good enough
            df["textloc"][i] = token_text_country_test["token"][0]
        except IndexError:
            df["textloc"][i] = ""
    
    #Step 8: Left Merge The Lat and Long into to the tweets
    kocoord = df
    return kocoord


# In[ ]:





# In[ ]:


#Use the Analyzer Functions


# In[ ]:


#Part 26: The English Analyzer Function
def english_df(English_Tweets):
    try:
        english_test_df = english_analysis(English_Tweets)
    except KeyError:
        english_test_df = pd.DataFrame()
    
    return english_test_df


# In[ ]:


#Part 27: The Spanish Analyzer Function
def spanish_df(Spanish_Tweets):
    try:
        spanish_test_df = spanish_analysis(Spanish_Tweets)
    except ValueError:
        spanish_test_df = pd.DataFrame()
        
    return spanish_test_df


# In[ ]:


#Part 28: The French Analyzer Function
def french_df(French_Tweets):
    try:
        french_test_df = french_analysis(French_Tweets)
    except:
        french_test_df = pd.DataFrame()
        
    return french_test_df


# In[ ]:


#Part 29: The Portuguese Analyzer Function
def portuguese_df(Portuguese_Tweets):
    try:
        portuguese_test_df = portuguese_analysis(Portuguese_Tweets)
    except:
        portuguese_test_df = pd.DataFrame()
        
    return portuguese_test_df


# In[ ]:


#Part 30: Call the Arabic Analyzer Function
def arabic_df(Arabic_Tweets):
    try:
        arabic_test_df_2 = arabic_analysis(Arabic_Tweets)
        arabic_test_df = arabic_test_df_2.loc[:, ~arabic_test_df_2.columns.duplicated()]
    except ValueError:
        arabic_test_df = pd.DataFrame()

    return arabic_test_df


# In[ ]:


#Part 31: Call the Japanese Analyzer Function
def japanese_df(Japanese_Tweets):
    try:
        japanese_test_df = japanese_analysis(Japanese_Tweets)
    except ValueError:
        japanese_test_df = pd.DataFrame()
    
    return japanese_test_df


# In[ ]:


#Part 32: Call the Korean Analyzer Function
def korean_df(Korean_Tweets):
    try:
        korean_test_df = korean_analysis(Korean_Tweets)
    except ValueError:
        korean_test_df = pd.DataFrame()
        
    return korean_test_df


# In[ ]:


#Part 33: Combine the Data Frames Function:
def create_full(english_test_df, spanish_test_df, french_test_df, portuguese_test_df, arabic_test_df, japanese_test_df, korean_test_df):
    en_sp_df = english_test_df.append(spanish_test_df)
    en_sp_df_2 = en_sp_df.reset_index(drop = True)
    en_sp_fr_df = en_sp_df_2.append(french_test_df)
    en_sp_fr_df_2 = en_sp_fr_df.reset_index(drop = True)
    en_sp_fr_pt_df = en_sp_fr_df_2.append(portuguese_test_df)
    en_sp_fr_pt_df_2 = en_sp_fr_pt_df.reset_index(drop = True)
    en_sp_fr_pt_ar_df = en_sp_fr_pt_df_2.append(arabic_test_df)
    en_sp_fr_pt_ar_df_2 = en_sp_fr_pt_ar_df.reset_index(drop = True)
    en_sp_fr_pt_ar_ja_df = en_sp_fr_pt_ar_df.append(japanese_test_df)
    en_sp_fr_pt_ar_ja_df_2 = en_sp_fr_pt_ar_ja_df.reset_index(drop = True)
    full_df_1 = en_sp_fr_pt_ar_ja_df.append(korean_test_df)
    full_df = full_df_1.drop(["Sentiment_label"], axis = 1)
    full_df.reset_index(drop = True, inplace = True)
    #full_df.to_csv(f'/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/full_df_test.csv')
    return full_df


# In[ ]:


#Part 34: Get the full data set without Duplicates Function:
def full_df_no_dups(full_df):
    full_df_no_dups = full_df.drop_duplicates(subset=['id'])
    return full_df_no_dups


# In[ ]:


#Part 35: Get the Topic Mentioned Counts List Function:
#https://stackoverflow.com/questions/19828822/how-to-check-whether-a-pandas-dataframe-is-empty
#https://stackoverflow.com/questions/30787901/how-to-get-a-value-from-a-pandas-dataframe-and-not-the-index-and-object-type
def topic_count_list(full_df_no_dups):
    full_topic_count = full_df_no_dups["tag"].value_counts()
    #Convert Series to dataframe
    topic_count_df = full_topic_count.to_frame()
    tcdf_index = topic_count_df.reset_index()
    tcdfi_cn = tcdf_index.rename(columns = {"index": "Topic", "tag": "Count"})
    #Loop through list to get counts
    topic_count_list = []
    lentl = len(topic_list)
    lentopic1 = len(tcdfi_cn["Topic"])
    found_topic_list = tcdfi_cn["Topic"].tolist()
    for i in range(0, lentl):
        try:
            topic_list_token = topic_list[i]
            if topic_list_token in found_topic_list:
                tcdfi_cn_token = tcdfi_cn.loc[tcdfi_cn["Topic"] == topic_list_token]
                tcdfi_cn_token2 = tcdfi_cn_token["Count"]
                tcdfi_cn_token3 = tcdfi_cn_token2.item()
                topic_count_list.append(tcdfi_cn_token3)
            else:
                topic_count_list.append(0)
        
        except KeyError:
            print("error")
            continue
    
    return topic_count_list


# In[ ]:


#Part 36: Function to append the new data file to the existing csv
def append_new_row(oldfile, outputrow):
    with open(oldfile, 'a+', newline = '') as write_obj:
        csv_writer = writer(write_obj)
        csv_writer.writerow(outputrow)


# In[ ]:


#Part 37: Convert topic_count_list to dataframe and transpose to store Function
def tcl_convert(topic_count_list, d1, max_file_name):
    #Combine the two list into a dataframe
    full_topic_count = pd.DataFrame(
        { "Topics": topic_list,
         "Count": topic_count_list
        })
    #Set Topics as index
    ftc = full_topic_count.set_index("Topics")
    #Transpose the dataframe so the topic index is now the column names 
    ftc_t = ftc.T
    #Add Time to the Transposed dataframe
    ftc_t["Time"] = d1
    ftc_t["File_name"] = max_file_name
    #Stores the new run of the program
    newoutputrow = [ftc_t.loc["Count"][0], ftc_t.loc["Count"][1], ftc_t.loc["Count"][2], ftc_t.loc["Count"][3], 
                    ftc_t.loc["Count"][4], ftc_t.loc["Count"][5], ftc_t.loc["Count"][6], 
                    ftc_t.loc["Count"][7], ftc_t.loc["Count"][8], ftc_t.loc["Count"][9], ftc_t.loc["Count"][10]]
    #Append new row to the csv file
    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Full_Topic_Count.csv", newoutputrow)


# In[ ]:


#Part 38: Get the Sentiment values for the different topics
#https://stackoverflow.com/questions/19828822/how-to-check-whether-a-pandas-dataframe-is-empty
#https://stackoverflow.com/questions/34421024/transforming-type-int64index-into-an-integer-index-in-python
def topic_sentiment_list(full_df_no_dups):
    #Calculate the senetiment by topic
    sent_topic_gb = full_df_no_dups.groupby(["tag"]).sum()
    stgb = sent_topic_gb.reset_index()
    stgb2 = stgb[["tag", "Sentiment"]]
    #Loop through list to get sentiments for all the Topics
    topic_sentiment_list = []
    lentl = len(topic_list)
    for i in range(0, lentl):
        try:
            topic_sentiment_token = topic_list[i]
            stgb2_token = stgb2.loc[stgb2["tag"] == topic_sentiment_token]
            if stgb2_token.empty:
                topic_sentiment_list.append(0.0)
            else:
                stgb2_token2 = stgb2_token["Sentiment"]
                index_token = stgb2_token.index.tolist()
                index_token2 = index_token[0]
                stgb2_token3 = stgb2_token2[index_token2]
                topic_sentiment_list.append(stgb2_token3)
        except KeyError:
            print("error")
            continue
    
    return topic_sentiment_list


# In[ ]:


#Part 39: Convert topic_sentiment_list to dataframe and transpose to store Function
def tsl_convert(topic_sentiment_list, d1, max_file_name):
    #Combine the two list into a dataframe
    full_topic_sentiment = pd.DataFrame(
        { "Topics": topic_list,
         "Sentiment": topic_sentiment_list
        })
    #Set Topics as index
    fts = full_topic_sentiment.set_index("Topics")
    #Transpose the dataframe so the topic index is now the column names
    fts_t = fts.T
    #Add Time to the Transposed dataframe
    fts_t["Time"] = d1
    fts_t["File_name"] = max_file_name
    #Stores the new run of the program
    newoutputrow_sent = [fts_t.loc["Sentiment"][0], fts_t.loc["Sentiment"][1], fts_t.loc["Sentiment"][2], 
                         fts_t.loc["Sentiment"][3], fts_t.loc["Sentiment"][4], fts_t.loc["Sentiment"][5], 
                         fts_t.loc["Sentiment"][6], fts_t.loc["Sentiment"][7], 
                         fts_t.loc["Sentiment"][8], fts_t.loc["Sentiment"][9], fts_t.loc["Sentiment"][10]]
    #Append the new row to dataset 
    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Full_Topic_Sentiment.csv", newoutputrow_sent)
    #For use in the finance - topic function
    return full_topic_sentiment


# In[ ]:


#Part 39.5a: Get the language counts for the tweets
#Loop through list to get the count for all the Languages
#This function uses the lang_list constant as a way to create a new list from the group_by data to transpose 
#the language count data. It first tries to match the lang from the group_by data to the lang from lang_list.
#If there is no tweet with the language then 0 is appended to the new lang_count_list in the spot where the
#lang_count should be. If there are tweets with the language, it goes through the group_by data to get the 
#lang count for each lang and adds them to the new lang_count_list. This applies for topic count and topic
#sentiment functions as well. 
def lang_count_list(full_df_no_dups):
    #Calculate the senetiment by topic
    lang_count_gb = full_df_no_dups.groupby(["lang"]).count()
    lcgb = lang_count_gb.reset_index()
    lcgb2 = lcgb[["lang", "created_at"]]
    #Loop through list to get sentiments for all the Topics
    lang_count_list = []
    lentl = len(lang_list)
    for i in range(0, lentl):
        try:
            lang_count_token = lang_list[i]
            lcgb2_token = lcgb2.loc[lcgb2["lang"] == lang_count_token]
            if lcgb2_token.empty:
                lang_count_list.append(0)
            else:
                lcgb2_token2 = lcgb2_token["created_at"]
                index_token = lcgb2_token.index.tolist()
                index_token2 = index_token[0]
                lcgb2_token3 = lcgb2_token2[index_token2]
                lang_count_list.append(lcgb2_token3)
        except KeyError:
            print("error")
            continue
    
    return lang_count_list


# In[ ]:


#Part 39.5b: Convert topic_sentiment_list to dataframe and transpose to store Function
def lcl_convert(lang_count_list, d1, max_file_name):
    #Combine the two list into a dataframe
    full_lang_count = pd.DataFrame(
        { "Lang": lang_list,
         "Count": lang_count_list
        })
    #Set Topics as index
    flc = full_lang_count.set_index("Lang")
    #Transpose the dataframe so the topic index is now the column names
    flc_t = flc.T
    #Add Time to the Transposed dataframe
    flc_t["Time"] = d1
    flc_t["File_name"] = max_file_name
    #Stores the new run of the program
    newoutputrow_lang = [flc_t.loc["Count"][0], flc_t.loc["Count"][1], flc_t.loc["Count"][2], 
                    flc_t.loc["Count"][3], flc_t.loc["Count"][4], flc_t.loc["Count"][5], 
                    flc_t.loc["Count"][6], flc_t.loc["Count"][7], flc_t.loc["Count"][8]]
    #Append the new row to dataset 
    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Lang_Count.csv", newoutputrow_lang)

# In[ ]:

#Part 40: Count Change over Time Function
#https://stackoverflow.com/questions/15862034/access-index-of-last-element-in-data-frame
#https://stackoverflow.com/questions/25063837/subtracting-two-dates-in-python
def count_over_time():
    #Import the Full Count csv
    full_topic_count_csv = pd.read_csv("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Full_Topic_Count.csv")
    #Create the Change of Count Variables
    goldsteinndelta = full_topic_count_csv["Goldstein Negative"].iloc[-1] - full_topic_count_csv["Goldstein Negative"].iloc[-2]
    goldsteinpdelta = full_topic_count_csv["Goldstein Positive"].iloc[-1] - full_topic_count_csv["Goldstein Positive"].iloc[-2]
    nuclearthrdelta = full_topic_count_csv["Nuclear Threat"].iloc[-1] - full_topic_count_csv["Nuclear Threat"].iloc[-2]
    cyberwarfaredelta = full_topic_count_csv["Cyber Warfare"].iloc[-1] - full_topic_count_csv["Cyber Warfare"].iloc[-2]
    WarTdelta = full_topic_count_csv["War Threats"].iloc[-1] - full_topic_count_csv["War Threats"].iloc[-2]
    oilshockdelta = full_topic_count_csv["Oil Supply Shock"].iloc[-1] - full_topic_count_csv["Oil Supply Shock"].iloc[-2]
    uschinadelta = full_topic_count_csv["US-China Relations"].iloc[-1] - full_topic_count_csv["US-China Relations"].iloc[-2]
    terrorismdelta = full_topic_count_csv["Terrorism"].iloc[-1] - full_topic_count_csv["Terrorism"].iloc[-2]
    GeopoliticalRdelta = full_topic_count_csv["Geopolitical Risks"].iloc[-1] - full_topic_count_csv["Geopolitical Risks"].iloc[-2]
    Time = full_topic_count_csv["Time"].iloc[-1]
    File_name = full_topic_count_csv["File_name"].iloc[-1]
    #Get the time delta
    x1 = datetime.strptime(full_topic_count_csv["Time"].iloc[-1], "%d/%m/%Y %H:%M:%S")
    y1 = datetime.strptime(full_topic_count_csv["Time"].iloc[-2], "%d/%m/%Y %H:%M:%S")
    Timedelta = (x1-y1).seconds
    #Create the new row of the outputs for the dataframe
    newrow_count_change = [Time, goldsteinndelta, goldsteinpdelta, nuclearthrdelta, cyberwarfaredelta, WarTdelta, 
                           oilshockdelta, uschinadelta, terrorismdelta, GeopoliticalRdelta, Timedelta, File_name]
    #Append new row
    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Full_Topic_Count_Change.csv", newrow_count_change)


# In[ ]:


#Part 41: Creating the Sentiment Change over Time Function
#Step 1: Import the Count csv
def sentiment_over_time():
    #Import the Full Sentiment csv
    full_topic_sent_csv = pd.read_csv("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Full_Topic_Sentiment.csv")
    #Create the Change of Count Variables
    goldsteinndelta_sent = full_topic_sent_csv["Goldstein Negative"].iloc[-1] - full_topic_sent_csv["Goldstein Negative"].iloc[-2]
    goldsteinpdelta_sent = full_topic_sent_csv["Goldstein Positive"].iloc[-1] - full_topic_sent_csv["Goldstein Positive"].iloc[-2]
    nuclearthrdelta_sent = full_topic_sent_csv["Nuclear Threat"].iloc[-1] - full_topic_sent_csv["Nuclear Threat"].iloc[-2]
    cyberwarfaredelta_sent = full_topic_sent_csv["Cyber Warfare"].iloc[-1] - full_topic_sent_csv["Cyber Warfare"].iloc[-2]
    WarTdelta_sent = full_topic_sent_csv["War Threats"].iloc[-1] - full_topic_sent_csv["War Threats"].iloc[-2]
    oilshockdelta_sent = full_topic_sent_csv["Oil Supply Shock"].iloc[-1] - full_topic_sent_csv["Oil Supply Shock"].iloc[-2]
    uschinadelta_sent = full_topic_sent_csv["US-China Relations"].iloc[-1] - full_topic_sent_csv["US-China Relations"].iloc[-2]
    terrorismdelta_sent = full_topic_sent_csv["Terrorism"].iloc[-1] - full_topic_sent_csv["Terrorism"].iloc[-2]
    GeopoliticalRdelta_sent = full_topic_sent_csv["Geopolitical Risks"].iloc[-1] - full_topic_sent_csv["Geopolitical Risks"].iloc[-2]
    Time_sent = full_topic_sent_csv["Time"].iloc[-1]
    File_name_sent = full_topic_sent_csv["File_name"].iloc[-1]
    #Get the time delta
    x1_sent = datetime.strptime(full_topic_sent_csv["Time"].iloc[-1], "%d/%m/%Y %H:%M:%S")
    y1_sent = datetime.strptime(full_topic_sent_csv["Time"].iloc[-2], "%d/%m/%Y %H:%M:%S")
    Timedelta_sent = (x1_sent-y1_sent).seconds
    #Create the new row of the outputs for the dataframe
    newrow_sent_change = [ Time_sent, goldsteinndelta_sent, goldsteinpdelta_sent, nuclearthrdelta_sent,
                           cyberwarfaredelta_sent, WarTdelta_sent, oilshockdelta_sent, uschinadelta_sent,
                           terrorismdelta_sent, GeopoliticalRdelta_sent, Timedelta_sent, File_name_sent]

    #Step 8: Append new row
    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Full_Topic_Sentiment_Change.csv", newrow_sent_change)


# In[ ]:


#Part 43: Translate the text location to English Function
def translate_to_english(full_df, counter_2, max_file_name):
    full_dflen = len(full_df["text"])
    full_df["textloc_en"] = ""
    for i in range(0, full_dflen):
        try:
            text = full_df["textloc"][i]
            translated = GoogleTranslator(source = "auto", to_lang = "english").translate(text=text)
            full_df["textloc_en"][i] = translated
        except:
            full_df["textloc_en"][i] = ""
    country_count = full_df.groupby(['textloc_en']).count()
    cc2 = country_count[["created_at"]]
    cc3 = cc2.rename(columns = {"created_at": "count"})
    cc4 = cc3.sort_values(by = ["count"], ascending = False)
    cc5 = cc4.head(10)
    mfn_str = str(max_file_name)
    mfn_str2 = mfn_str[0:-4]
    cc5.to_csv("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Country_Counts/cc_" + str(mfn_str2) + ".csv")
    return full_df


# In[ ]:


#Part 44: Economic Recommendation Function 1: Commodities Sector
#Merge the full df with the Country-Product DataFrame function
#Might not use
def country_product(full_df, d1, max_file_name, counter_2):
    try:
        #Merge the Country Product Data Frame
        full_country = full_df.merge(country_product_2, on = "textloc_en", how = "left")
        #Merge the Topic Product Data Frame
        full_country_topic = full_country.merge(Topic_Product_2, on = "tag", how = "left")
        #Convert the Market_Affected Columns to Lists, using split str
        full_country_topic["MA_List_Pos"] = ""
        full_country_topic["MA_List_Neg"] = ""
        lenfct = len(full_country_topic["MA_List_Neg"])
        for i in range(0, lenfct):
            full_country_topic["MA_List_Pos"][i] = full_country_topic["Markets_Affected_Positive"][i].split(",")
            full_country_topic["MA_List_Neg"][i] = full_country_topic["Markets_Affected_Negative"][i].split(",")
        #See if Export is affected by Geopolitical Risk
        #Positive
        full_country_topic["Export_Pos"] = ""
        for i in range(0, lenfct):
            try:
                export_token = full_country_topic["Top_Export"][i]
                et_str = str(export_token)
                #print(export_token)
                #print(et_str)
                #print(type(export_token))
                #print(type(et_str))
                et_list = et_str.split(" ")
                #print(et_list)
                fctp = full_country_topic["MA_List_Pos"][i]
                #print(fctp)
                #print(type(fctp))
                #convert export token to string then to list
                #get the overlap between the two lists
                settest = set(et_list) & set(fctp)
                #print(settest)
                #convert the new set into a list
                listp = list(settest)
                #print(listp)
                #if the list is not empty, add list to export pos, if it is, leave empty
                if not listp:
                    full_country_topic["Export_Pos"][i] = ""
                else:
                    full_country_topic["Export_Pos"][i] = listp
            except KeyError:
                print("error")
                continue
        #See if Export is affected by Geopolitical Risk
        #Negative
        full_country_topic["Export_Neg"] = ""
        for i in range(0, lenfct):
            try:
                export_token2 = full_country_topic["Top_Export"][i]
                et2_str = str(export_token2)
                #print(export_token2)
                #print(et2_str)
                #print(type(export_token2))
                #print(type(et2_str))
                et2_list = et2_str.split(" ")
                #print(et2_list)
                fctn = full_country_topic["MA_List_Neg"][i]
                #print(fctn)
                #print(type(fctn))
                settest2 = set(et2_list) & set(fctn)
                #print(settest2)
                listn = list(settest2)
                #print(listn)
                if not listn:
                    full_country_topic["Export_Neg"][i] = ""
                else:
                    full_country_topic["Export_Neg"][i] = listn
            except KeyError:
                print("error")
                continue
                
        #Create new variables for appending the new row
        #Time
        for i in range(0, lenfct):
            export_n = full_country_topic["Export_Neg"][i]
            export_p = full_country_topic["Export_Pos"][i]
            if (not export_n and not export_p):
                i+= 1
                #continue
            elif (not export_p and export_n != []): 
                new_fct_new_row = [d1, full_country_topic["textloc_en"][i], "No Change",
                                   full_country_topic["Export_Neg"][i], full_country_topic["Top_Exporter"][i],
                                   full_country_topic["specific_goods"][i], full_country_topic["tag"][i], max_file_name, counter_2]
                append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Export_Topic_Results.csv", new_fct_new_row)
            elif (not export_n and export_p != []):
                new_fct_new_row = [d1, full_country_topic["textloc_en"][i], full_country_topic["Export_Pos"][i],
                                   "No Change", full_country_topic["Top_Exporter"][i],
                                   full_country_topic["specific_goods"][i], full_country_topic["tag"][i], max_file_name, counter_2]
                append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Export_Topic_Results.csv", new_fct_new_row)       
            else:
                i += 1
                #continue
                #new_fct_new_row = [d1, full_country_topic["textloc_en"][i],
                #                   full_country_topic["Export_Pos"][i], full_country_topic["Export_Neg"][i], full_country_topic["Top_Exporter"][i],
                #                   full_country_topic["specific_goods"][i], full_country_topic["tag"][i]]
                #append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Export_Topic_Results.csv", new_fct_new_row)
        
        full_country_topic.to_csv(f'/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/full_country_topic_test.csv')
    except:
        print("error")
        new_fct_new_row = [d1, full_country_topic["textloc_en"][i],
                                   "No Change", "No Change", full_country_topic["Export_Neg"][i], full_country_topic["Top_Exporter"][i],
                           full_country_topic["specific_good"][i], full_country_topic["tag"][i], max_file_name, counter_2]
        append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Export_Topic_Results.csv", new_fct_new_row)
        

# In[ ]:


#Part 45: Economic Recommendation Function 2: Finance Market Sector
#Step 1: Get the Sentiment Data Frame
#This is the dataframe that has the sum of the Sentiment values for the tweets in this section
#Now the question will be, do I use the change over time or the value at the time to make the Economic Recommendation
#or use a larger time frame to do so
def finance_topic(full_topic_sentiment, d1, max_file_name,counter_2):
    #Merge the Topics with full sentiment
    full_finance = full_topic_sentiment.merge(Topic_Finance_2, on = "Topics", how = "left")
    #Show the Economic Recommendations
    lenff = len(full_finance["Topics"])
    for i in range(0, lenff):
        if full_finance["Sentiment"][i] < 0:
            print(full_finance["Topics"][i] + ":")
            print("Sentiment " + str(full_finance["Sentiment"][i]))
            print(full_finance["Markets_Affected_Negative"][i])
            print("Will Decrease in Value")
            print("")
            print(full_finance["Topics"][i] + ":")
            print("Sentiment " + str(full_finance["Sentiment"][i]))
            print(full_finance["Markets_Affected_Positive"][i])
            print("Will Increase in Value")
            print("")
        elif full_finance["Sentiment"][i] > 0:
            print(full_finance["Topics"][i] + ":")
            print("Sentiment " + str(full_finance["Sentiment"][i]))
            print(full_finance["Markets_Affected_Positive"][i])
            print("Will Increase in Value")
            print("")
            print(full_finance["Topics"][i] + ":")
            print("Sentiment " + str(full_finance["Sentiment"][i]))
            print(full_finance["Markets_Affected_Negative"][i])
            print("Will Decrease in Value")
            print("")
        else:
            print(full_finance["Topics"][i] + ":")
            print("Sentiment " + str(full_finance["Sentiment"][i]))
            print("No Change")
            print("")
            
    #Step 2: Output a new line for each asset and store it 
    lenff = len(full_finance)
    full_finance["List_MAN"] = ""
    full_finance["List_MAP"] = ""
    try:
        for i in range(0, lenff):
            full_finance["List_MAN"][i] = (full_finance["Markets_Affected_Negative"][i]).split(", ")
            full_finance["List_MAP"][i] = (full_finance["Markets_Affected_Positive"][i]).split(", ")
            if full_finance["Sentiment"][i] < 0:
                lenln = len(full_finance["List_MAN"][i])
                lenlp = len(full_finance["List_MAP"][i])
                for j in range(0, lenln):
                    newftrrow = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i], 
                                 full_finance["List_MAN"][i][j], 0, 1, max_file_name, counter_2]
                    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow)
                for k in range(0, lenlp):
                    newftrrow2 = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i], 
                                  full_finance["List_MAP"][i][k], 1, 0, max_file_name, counter_2]
                    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow2)
            elif full_finance["Sentiment"][i] > 0:
                lenln = len(full_finance["List_MAN"][i])
                lenlp = len(full_finance["List_MAP"][i])
                for j in range(0, lenln):
                    newftrrow = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i], 
                                 full_finance["List_MAN"][i][j], 0, 1, max_file_name, counter_2]
                    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow)
                for k in range(0, lenlp):
                    newftrrow2 = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i], 
                                  full_finance["List_MAP"][i][k], 1, 0, max_file_name, counter_2]
                    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow2)
            else:
                lenln = len(full_finance["List_MAN"][i])
                lenlp = len(full_finance["List_MAP"][i])
                for j in range(0, lenln):
                    newftrrow = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i], 
                                 full_finance["List_MAN"][i][j], 0, 0, max_file_name, counter_2]
                    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow)
                for k in range(0, lenlp):
                    newftrrow2 = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i], 
                                  full_finance["List_MAP"][i][k], 0, 0, max_file_name, counter_2]
                    append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow2)
    except:
        newftrrow = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i],
                     "None", 0, 0, max_file_name, counter_2]
        append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow)
        newftrrow2 = [d1, full_finance["Topics"][i], full_finance["Sentiment"][i],
                      "None", 0, 0, max_file_name, counter_2]
        append_new_row("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Finance_Topic_Results.csv", newftrrow2)


# In[ ]:


#Part 45.5: Counter Updater Function
def counter_updater(counter):
    counter = counter + 1
    return counter


# In[ ]:


#Step 46: Construct the Main Function 
def main_full(counter_2):
    #counter_2 = 0
    df = latest_file(folder_path, file_type, counter_2)
    max_file_name = name_latest_file(folder_path, file_type)
    d1 = datetimenow()
    df2 = lang_loop(df)
    df3 = word_count(df2)
    English_Tweets_2 = English_Tweets_Func(df3)
    Spanish_Tweets_2 = Spanish_Tweets_Func(df3)
    French_Tweets_2 = French_Tweets_Func(df3)
    Portuguese_Tweets_2 = Portuguese_Tweets_Func(df3)
    Arabic_Tweets_2 = Arabic_Tweets_Func(df3)
    Japanese_Tweets_2 = Japanese_Tweets_Func(df3)
    Korean_Tweets_2 = Korean_Tweets_Func(df3)
    entweet_coord = english_df(English_Tweets_2)
    sptweet_coord = spanish_df(Spanish_Tweets_2)
    frtweet_coord = french_df(French_Tweets_2)
    pttweet_coord = portuguese_df(Portuguese_Tweets_2)
    artweet_coord = arabic_df(Arabic_Tweets_2)
    jatweet_coord = japanese_df(Japanese_Tweets_2)
    kotweet_coord = korean_df(Korean_Tweets_2)
    full_df_2 = create_full(entweet_coord, sptweet_coord, frtweet_coord, pttweet_coord, artweet_coord, jatweet_coord, kotweet_coord)
    full_df_2_no_dups = full_df_no_dups(full_df_2)
    topic_cl_2 = topic_count_list(full_df_2_no_dups)
    tcl_convert(topic_cl_2, d1, max_file_name)
    topic_sl_2 = topic_sentiment_list(full_df_2_no_dups)
    full_topic_sentiment_2 = tsl_convert(topic_sl_2, d1, max_file_name)
    lang_cl = lang_count_list(full_df_2_no_dups)
    lcl_convert(lang_cl, d1, max_file_name)
    count_over_time()
    sentiment_over_time()
    #making_map(full_df_2, counter_2)
    full_df_3 = translate_to_english(full_df_2, counter_2, max_file_name)
    country_product(full_df_3, d1, max_file_name, counter_2)
    finance_topic(full_topic_sentiment_2, d1, max_file_name, counter_2)
    counter_2 = counter_updater(counter_2)


# In[ ]:


#####################################################################################################################
#####################################################################################################################


# In[ ]:


#Mapping Functions and Main Functions


# In[ ]:


#Part 13: THIS IS THE ENGLISH ANALYSIS FUNCTION
def english_analysis_2(df):
    #Length of the English Tweets
    LenEnT = len(df.index)
    LenEnT

    #Create a new dataframe
    EnTCompound = pd.DataFrame([])
    EnTSentence = pd.DataFrame([])

    #This loop takes the contents from each article, tokenizes each sentence in the article, counts the number of 
    #sentences in the article and then gets the sentiments of each sentence and exports those sentiments to a dataframe
    for i in np.arange(0, LenEnT):
        dtestent = df["text"][i]
        dictionary = sentianalyzer.polarity_scores(dtestent)
        c1 = dictionary.get('compound')
        EnTCompound = EnTCompound.append(pd.DataFrame({'Compound': c1}, index = [0]), ignore_index = True)
    
    #Add the Sentiment to the DataFrame
    frames = [df, EnTCompound]
    finalent = pd.concat(frames, axis = 1)
    
    #Normalize the Sentiment
    #1. Conditions
    conditions_eng = [
        (finalent['Compound'] <= -0.25),
        (finalent['Compound'] > -0.25) & (finalent['Compound'] < 0.25),
        (finalent['Compound'] >= 0.25)
    ]
    
    #2. Values
    values_eng = [-1, 0, 1]
    
    #3. New Variable
    finalent['Sentiment'] = np.select(conditions_eng, values_eng)
    
    #Matching Patterns for countries for GeoCoding
    lenentw = len(finalent["text"])

    #Create a new dataframe
    ettext = pd.DataFrame([])
    etlabel = pd.DataFrame([])
    ettweet = pd.DataFrame([])

    #Initialize the NLP in Spacy
    nlp = spacy.load("en_core_web_sm")
    for i in np.arange(0, lenentw):
        etspacy = finalent["text"][i]
        doc = nlp(etspacy)
        for ent in doc.ents:
            ettext = ettext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            etlabel = etlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            ettweet = ettweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Combining the Spacy Findings
    frames_spacy = [ettweet, ettext, etlabel]
    finalent_spacy = pd.concat(frames_spacy, axis = 1)
    
    #Keep only the GPE entities
    gpedf = finalent_spacy[finalent_spacy['label'] == "GPE"]
    
    #Left Merge Back the GPE labels to the tweets
    etlocations = pd.merge(finalent, gpedf, on = "TweetNumber", how = "left")
    
    #Get the coordinates from Google Maps API
    #Make the empty dataframes
    etlat = pd.DataFrame([])
    etlong = pd.DataFrame([])
    ettweet_2 = pd.DataFrame([])
    
    #Create the lat and long variables to add to the data
    lenentw = len(etlocations["text"])

    #If there is no location given, then the coordinates will be (Zero, Zero), if they do exist, use the Geocoding
    #API to find the coordinates of those places
    for i in np.arange(0, lenentw):
        etloc = etlocations['textloc'][i]
        geo_code_result = gmaps.geocode(etloc)
        if pd.isna(etloc) == True:
            etlat = etlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            etlong = etlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            ettweet_2 = ettweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        #If the google maps can't find a location for the text country, append (0,0) for coordinates
        elif len(geo_code_result) == 0:
            etlat = etlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            etlong = etlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            ettweet_2 = ettweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        else:
            geo_code_dict = geo_code_result[0]
            geo_code_geometry_dict = geo_code_dict.get('geometry')
            geo_location = geo_code_geometry_dict.get('location')
            etlat = etlat.append(pd.DataFrame({'Lat': geo_location.get('lat')}, index = [0]), ignore_index = True)
            etlong = etlong.append(pd.DataFrame({'Long': geo_location.get('lng')}, index = [0]), ignore_index = True)
            ettweet_2 = ettweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Concatenate dataframes
    framesloc = [etlat, etlong]
    finalloc = pd.concat(framesloc, axis = 1)
    
    #Left Merge The Lat and Long into to the tweets
    frames_2 = [etlocations, finalloc]
    etcoord = pd.concat(frames_2, axis = 1)
    
    return etcoord


# In[ ]:


#Part 15: THIS IS THE SPANISH ANALYSIS FUNCTION
#https://stackoverflow.com/questions/38895768/python-pandas-dataframe-is-it-pass-by-value-or-pass-by-reference
def spanish_analysis_2(df):
    
    #Part 1: Sentiment Analysis with Spanish RNN
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    
    twsp_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data
    batch_size = 2
    twsp_ran_set = twsp_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twsp_predict = RNN_sp_model.predict(twsp_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twsp_predict.tolist()
    
    #Step 5: Convert Results to -1, 1
    lendtt = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendtt):
        df["Sentiment"][i] = convert_sp(df, i)
    
    
    #Part 2: Get the NER, Location Text, and Coordinates 
    
    #Get the length of the finalspt dataframe
    lensptw = len(df["text"])

    #First: Create the new dataframes to capture the different NER parts
    spttext = pd.DataFrame([])
    sptlabel = pd.DataFrame([])
    spttweet = pd.DataFrame([])

    #Second: Initialize the NLP in Spacy
    nlp = spacy.load("es_core_news_sm")
    for i in np.arange(0, lensptw):
        sptspacy = df["text"][i]
        doc_sp = nlp(sptspacy)
        for ent in doc_sp.ents:
            spttext = spttext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            sptlabel = sptlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            spttweet = spttweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Third: Combining the Spacy Spanish Findings
    frames_spacy_sp = [spttweet, spttext, sptlabel]
    finalent_spacy_sp = pd.concat(frames_spacy_sp, axis = 1)
    
    #Fourth: Keep only the GPE parts 
    gpedf_sp = finalent_spacy_sp[finalent_spacy_sp['label'] == "LOC"]
    
    #Fifth: Merge the GPE on the Main Data Frame
    sptlocations = pd.merge(df, gpedf_sp, on = "TweetNumber", how = "left")
    
    #ADD THE LAT AND LONG ONCE THAT GETS WORKING FOR NOW JUST RETURN THE LOCATIONS
    #ISSUE WHAT TO DO WITH THE "LOC" THAT AREN'T GPE, DOES THE LAT AND LOC GOOGLE API JUST RETURN ZERO, ZERO
    #HOPEFULLY THEN I
    
    #Make the empty dataframes for lat and long
    sptlat = pd.DataFrame([])
    sptlong = pd.DataFrame([])
    spttweet_2 = pd.DataFrame([])
    
    #Create the lat and long variables to add to the data
    
    lensptw = len(sptlocations["text"])

    #Initalize the loop for the API
    for i in np.arange(0, lensptw):
        sptloc = sptlocations['textloc'][i]
        geo_code_result_sp = gmaps.geocode(sptloc)
        #If there is no location in the tweet, enter (0,0) for lat and long
        if pd.isna(sptloc) == True:
            sptlat = sptlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            sptlong = sptlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            spttweet_2 = spttweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        #If the API can not find coordinates for the location, enter (0,0) for lat and long
        elif len(geo_code_result_sp) == 0:
            sptlat = sptlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            sptlong = sptlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            spttweet_2 = spttweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        #Else, get the lat and long from the dictionaries and subdictionaries
        else:
            geo_code_dict_sp = geo_code_result_sp[0]
            geo_code_geometry_dict_sp = geo_code_dict_sp.get('geometry')
            geo_location_sp = geo_code_geometry_dict_sp.get('location')
            sptlat = sptlat.append(pd.DataFrame({'Lat': geo_location_sp.get('lat')}, index = [0]), ignore_index = True)
            sptlong = sptlong.append(pd.DataFrame({'Long': geo_location_sp.get('lng')}, index = [0]), ignore_index = True)
            spttweet_2 = spttweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Concatenate dataframes
    #https://pandas.pydata.org/docs/user_guide/merging.html
    framesloc_sp = [sptlat, sptlong]
    finalloc_sp = pd.concat(framesloc_sp, axis = 1)
    
    #Left Merge The Lat and Long into to the tweets
    frames_2_sp = [sptlocations, finalloc_sp]
    sptcoord = pd.concat(frames_2_sp, axis = 1)
    
    return sptcoord


# In[ ]:


#Part 17: French Analysis Function Update
def french_analysis_2(df):
    
    #Part 1: Sentiment Analysis
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twfr_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 128
    twfr_ran_set = twfr_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twfr_predict = RNN_fr_model.predict(twfr_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twfr_predict.tolist()
    
    #Step 5: Convert Results to -1, 1
    lendfr = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendfr):
        df["Sentiment"][i] = convert_fr(df, i)
    
    #Part 2: Get the NER, Location Text, and Coordinates, 
    
    #Step 4: Put the Index Number as Tweet Number
    #https://stackoverflow.com/questions/20461165/how-to-convert-index-of-a-pandas-dataframe-into-a-column
    df["TweetNumber"] = df.index
    
    #Step 5: NER Spacy for French 
    lendfr2 = len(df["text"])

    #Create a new dataframe
    frtext = pd.DataFrame([])
    frlabel = pd.DataFrame([])
    frtweet = pd.DataFrame([])

    #Initialize the NLP in Spacy
    nlp_fr_sp = spacy.load("fr_core_news_sm")
    for i in np.arange(0, lendfr2):
        frspacy = df["text"][i]
        doc = nlp_fr_sp(frspacy)
        for ent in doc.ents:
            frtext = frtext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            frlabel = frlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            frtweet = frtweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Step 6: Combining the Spacy Findings
    frames_spacy_fr = [frtweet, frtext, frlabel]
    finalent_spacy_fr = pd.concat(frames_spacy_fr, axis = 1)
    
    #Step 7: Keep only the LOC entities
    gpedf_fr = finalent_spacy_fr[finalent_spacy_fr['label'] == "LOC"]
    
    #Step 8: Left Merge Back the GPE labels to the tweets
    frlocations = pd.merge(df, gpedf_fr, on = "TweetNumber", how = "left")
    
    #Step 9: Get the coordinates (lat and long)
    #Make the empty dataframes
    frlat = pd.DataFrame([])
    frlong = pd.DataFrame([])
    frtweet_2 = pd.DataFrame([])
    
    #Step 10: Create the lat and long variables to add to the data
    #https://towardsdatascience.com/5-methods-to-check-for-nan-values-in-in-python-3f21ddd17eed
    lenfrtw = len(frlocations["text"])

    for i in np.arange(0, lenfrtw):
        frloc = frlocations['textloc'][i]
        geo_code_result_fr = gmaps.geocode(frloc)
        if pd.isna(frloc) == True:
            frlat = frlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            frlong = frlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            frtweet_2 = frtweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        elif len(geo_code_result_fr) == 0:
            frlat = frlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            frlong = frlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            frtweet_2 = frtweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        else:
            geo_code_dict_fr = geo_code_result_fr[0]
            geo_code_geometry_dict_fr = geo_code_dict_fr.get('geometry')
            geo_location_fr = geo_code_geometry_dict_fr.get('location')
            frlat = frlat.append(pd.DataFrame({'Lat': geo_location_fr.get('lat')}, index = [0]), ignore_index = True)
            frlong = frlong.append(pd.DataFrame({'Long': geo_location_fr.get('lng')}, index = [0]), ignore_index = True)
            frtweet_2 = frtweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Step 11: Concatenate dataframes
    #https://pandas.pydata.org/docs/user_guide/merging.html
    framesloc_fr = [frlat, frlong]
    finalloc_fr = pd.concat(framesloc_fr, axis = 1)
    
    #Step 12: Left Merge The Lat and Long into to the tweets
    frames_2_fr = [frlocations, finalloc_fr]
    frcoord = pd.concat(frames_2_fr, axis = 1)
    
    return frcoord


# In[ ]:


#Part 19: Main Portuguese Function
def portuguese_analysis_2(df):
    
    #Part 1: Sentiment Analysis
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twpt_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 4
    twpt_ran_set = twpt_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twpt_predict = RNN_pt_model.predict(twpt_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twpt_predict.tolist()
    
    #Step 5: Convert Results to 0, 1
    lendtt = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendtt):
        df["Sentiment"][i] = convert_pt_rnn(df, i)
    
    #Part 2: Named Entity Recognition and Geocoding for Coordinates
    
    #Step 1: Length of Dataframe
    lenpttw = len(df["text"])

    #Step 2: Create a new dataframe for Appending
    pttext = pd.DataFrame([])
    ptlabel = pd.DataFrame([])
    pttweet = pd.DataFrame([])

    #Step 3: Initialize the NLP in Spacy
    nlp_pt = spacy.load("pt_core_news_sm")
    for i in np.arange(0, lenpttw):
        ptspacy = df["text"][i]
        doc = nlp_pt(ptspacy)
        for ent in doc.ents:
            pttext = pttext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
            ptlabel = ptlabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
            pttweet = pttweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            
    #Step 4: Combining the Spacy Findings
    frames_spacy_pt = [pttweet, pttext, ptlabel]
    finalpt_spacy = pd.concat(frames_spacy_pt, axis = 1)
    
    #Step 5: Keep only the LOC entities
    gpedf_pt = finalpt_spacy[finalpt_spacy['label'] == "LOC"]
    
    #Step 6: Left Merge Back the GPE labels to the tweets
    ptlocations = pd.merge(df, gpedf_pt, on = "TweetNumber", how = "left")
    
    #Step 7: #Get the coordinates
    #Make the empty dataframes
    ptlat = pd.DataFrame([])
    ptlong = pd.DataFrame([])
    pttweet_2 = pd.DataFrame([])
    
    #Step 8: Create the lat and long variables to add to the data
    
    lenpttw = len(ptlocations["text"])

    for i in np.arange(0, lenpttw):
        ptloc = ptlocations['textloc'][i]
        geo_code_result_pt = gmaps.geocode(ptloc)
        if pd.isna(ptloc) == True:
            ptlat = ptlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            ptlong = ptlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            pttweet_2 = pttweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        elif len(geo_code_result_pt) == 0:
            ptlat = ptlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            ptlong = ptlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            pttweet_2 = pttweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        else:
            geo_code_dict_pt = geo_code_result_pt[0]
            geo_code_geometry_dict_pt = geo_code_dict_pt.get('geometry')
            geo_location_pt = geo_code_geometry_dict_pt.get('location')
            ptlat = ptlat.append(pd.DataFrame({'Lat': geo_location_pt.get('lat')}, index = [0]), ignore_index = True)
            ptlong = ptlong.append(pd.DataFrame({'Long': geo_location_pt.get('lng')}, index = [0]), ignore_index = True)
            pttweet_2 = pttweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Step 9: Concatenate dataframes of the Lat and Long
    framesloc_pt = [ptlat, ptlong]
    finalloc_pt = pd.concat(framesloc_pt, axis = 1)
    
    #Step 10: Left Merge The Lat and Long into to the tweets
    frames_2_pt = [ptlocations, finalloc_pt]
    ptcoord = pd.concat(frames_2_pt, axis = 1)

    return ptcoord


# In[ ]:


#Part 21: Main Arabic Analysis Function
def arabic_analysis_2(df):
    
    #Part 1: Sentiment Analysis
    
    #Step 1: Use the tranformer to get the sentiment 
    lendar2 = len(df)
    df["Sentiment_label"] = ""
    for i in range(0, lendar2):
        ar_sa_test = sa_ar(df["text"][i])
        df["Sentiment_label"][i] = ar_sa_test[0]['label']
    
    #Step 2: Convert the Results
    df["Sentiment"] = 0
    for i in range(0, lendar2):
        df["Sentiment"][i] = convert_ar(df, i)
            
    #Part 2: Use the Second Tranformer for the NER Locations
    
    #Step 1: Get the list of locations named in tweets
    df["Location"] = ""
    lennat2 = len(df)
    for i in range(0, lennat2):
        named_test1 = nlp_ar_2(df["text"][i])
        if not named_test1:
            df["Location"][i] = "---"
        else:
            entity_list = []
            word_list = []
            for j in range(0, len(named_test1)):
                entity_list.append(named_test1[j]["entity"])
                word_list.append(named_test1[j]["word"])
                entity_index = [m for m, x in enumerate(entity_list) if x == "LABEL_4"]
                location_list = [word_list[k] for k in entity_index]
            df["Location"][i] = location_list
            
    #Step 2: Get a Single Location
    #This might be changed in the future if I can make multiple copies of a tweet for each location
    df["textloc"] = ""
    for i in range(0, len(df["textloc"])):
        if not df["Location"][i]:
            df["textloc"][i] = "---"
        else:
            single_loc = df["Location"][i][0]
            df["textloc"][i] = single_loc
            
    #Step 3: Drop the All Locations
    df2 = df.drop(["Location"], axis = 1)
    
    #Step 4: Get the coordinates
    #Make the empty dataframes
    arlat = pd.DataFrame([])
    arlong = pd.DataFrame([])
    artweet_2 = pd.DataFrame([])
    
    #Step 5: Create the lat and long variables to add to the data
    lenartw = len(df2["text"])

    for i in np.arange(0, lenartw):
        arloc = df2['textloc'][i]
        geo_code_result_ar = gmaps.geocode(arloc)
        if pd.isna(arloc) == True:
            arlat = arlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            arlong = arlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            artweet_2 = artweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        elif len(geo_code_result_ar) == 0:
            arlat = arlat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            arlong = arlong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            artweet_2 = artweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        else:
            geo_code_dict_ar = geo_code_result_ar[0]
            geo_code_geometry_dict_ar = geo_code_dict_ar.get('geometry')
            geo_location_ar = geo_code_geometry_dict_ar.get('location')
            arlat = arlat.append(pd.DataFrame({'Lat': geo_location_ar.get('lat')}, index = [0]), ignore_index = True)
            arlong = arlong.append(pd.DataFrame({'Long': geo_location_ar.get('lng')}, index = [0]), ignore_index = True)
            artweet_2 = artweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Step 6: Combining the HF Findings
    frames_hf_ar = [arlat, arlong, artweet_2]
    finalent_hf_ar = pd.concat(frames_hf_ar, axis = 1)
    
    #Step 7: Left Merge The Lat and Long into to the tweets
    frames_2_ar = [df2, finalent_hf_ar]
    arcoord_1 = pd.concat(frames_2_ar, axis = 1)
    arcoord = arcoord_1.reset_index(drop = True)
    
    return arcoord


# In[ ]:


#Part 23: The Main Japanese Function
def japanese_analysis_2(df):
    
    #Part 1: Sentiment Analysis
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twja_ran = (
    tf.data.Dataset.from_tensor_slices(
    
        (
            tf.cast(df['text'].values, tf.string),
            
        )
        
        )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 32
    twja_ran_set = twja_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twja_predict = RNN_ja_model.predict(twja_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twja_predict.tolist()
    
    #Step 5: Convert Results to -1, 0, 1
    lendttja = len(df)
    df["Sentiment"] = 0
    for i in range(0, lendttja):
        df["Sentiment"][i] = convert_japanese(df, i)
            
    #Part 2: Named Entity Recognition Japanese
    
    #Step 1: Length of Dataframe
    lenjatw = len(df["text"])
    
    #Step 2: Create a new dataframe for Appending
    jatext = pd.DataFrame([])
    jalabel = pd.DataFrame([])
    jatweet = pd.DataFrame([])
    
    #Step 3: Initialize the NLP in Spacy
    nlp_ja = spacy.load("ja_core_news_sm")
    for i in np.arange(0, lenjatw):
        jaspacy = df["text"][i]
        doc = nlp_ja(jaspacy)
        if not doc.ents:
            jatext = jatext.append(pd.DataFrame({'textloc': np.nan}, index = [0]), ignore_index = True)
            jalabel = jalabel.append(pd.DataFrame({'label': np.nan}, index = [0]), ignore_index = True)
            jatweet = jatweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        else:
            for ent in doc.ents:
                jatext = jatext.append(pd.DataFrame({'textloc': ent.text}, index = [0]), ignore_index = True)
                jalabel = jalabel.append(pd.DataFrame({'label': ent.label_}, index = [0]), ignore_index = True)
                jatweet = jatweet.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            
    #Step 4: Combining the Spacy Findings
    frames_spacy_ja = [jatweet, jatext, jalabel]
    finalja_spacy = pd.concat(frames_spacy_ja, axis = 1)
    
    #Step 5: Keep only the GPE entities
    gpedf_ja = finalja_spacy #[finalja_spacy["label"] == "GPE"]
    
    #Step 6: Left Merge Back the GPE labels to the tweets
    jalocations = pd.merge(df, gpedf_ja, on = "TweetNumber", how = "left")
    
    #Step 7: #Get the coordinates
    #Make the empty dataframes
    jalat = pd.DataFrame([])
    jalong = pd.DataFrame([])
    jatweet_2 = pd.DataFrame([])
    
    #Step 8: Create the lat and long variables to add to the data
    lenjatw = len(jalocations["text"])
    
    #Step 8.1: Implement the Google Maps API to get the coordinates for the countires
    for i in np.arange(0, lenjatw):
        jaloc = jalocations['textloc'][i]
        geo_code_result_ja = gmaps.geocode(jaloc)
        #If there is no location in the text, then return (0,0) for coordinates
        if pd.isna(jaloc) == True:
            jalat = jalat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            jalong = jalong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            jatweet_2 = jatweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        #If the API can't find the location / GPE, then return (0,0) for coordinates
        elif len(geo_code_result_ja) == 0:
            jalat = jalat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            jalong = jalong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            jatweet_2 = jatweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        #Else get the lat and long from the dictionaries and sub-dictionaries returned by the API
        else:
            geo_code_dict_ja = geo_code_result_ja[0]
            geo_code_geometry_dict_ja = geo_code_dict_ja.get('geometry')
            geo_location_ja = geo_code_geometry_dict_ja.get('location')
            jalat = jalat.append(pd.DataFrame({'Lat': geo_location_ja.get('lat')}, index = [0]), ignore_index = True)
            jalong = jalong.append(pd.DataFrame({'Long': geo_location_ja.get('lng')}, index = [0]), ignore_index = True)
            jatweet_2 = jatweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            
    #Step 9: Concatenate dataframes of the Lat and Long
    framesloc_ja = [jalat,jalong]
    finalloc_ja = pd.concat(framesloc_ja, axis = 1)
    
    #Step 10: Left Merge The Lat and Long into to the tweets
    frames_2_ja = [jalocations, finalloc_ja]
    jacoord = pd.concat(frames_2_ja, axis = 1)
    
    return jacoord


# In[ ]:


#Part 25: Korean Analysis Function
def korean_analysis_2(df):

    #Part 1: Sentiment Analysis with Korean RNN
    
    #Step 1: Transform the pandas data frame into a tensor frame dataframe for text
    twko_ran = (
        tf.data.Dataset.from_tensor_slices(
            
            (
                tf.cast(df['text'].values, tf.string),
            )
            
            )
    )
    
    #Step 2: Batch the data, hopefully
    batch_size = 4
    twko_ran_set = twko_ran.batch(batch_size).prefetch(1)
    
    #Step 3: Predict the Sentiment for the data
    twko_predict = RNN_ko_model.predict(twko_ran_set)
    
    #Step 4: Append the predictions to the pandas dataframe 
    df["results"] = twko_predict.tolist()
    
    #Step 5: Convert Results to -1, 0, 1
    lendttko = len(df["text"])
    df["Sentiment"] = 0
    for i in range(0, lendttko):
        df["Sentiment"][i] = convert_korean(df, i)
  
    #Part 2: Text Country and Coordinates  from the text
    
    #Step 1: Create the text_country variable
    df["textloc"] = ""
    lenk2test = len(df["textloc"])
    for i in range(0, lenk2test):
        try:
            #Step 2: Get the text
            text_2 = df["text"][i]
            #Step 3: Using Konlpy get the tokenization of the text and 
            #Transform it into a pandas dataframe
            kt_df_2 = pd.DataFrame(okt.morphs(text_2, norm = True, stem = True))
            kt_df_2.columns = ['name']
            #Step 3: Merge the Token DataFrame on the Tokenized Sentiment Lexicon
            token_text_country_test = pd.merge(kt_df_2, df_ko_world, on = "name", how = "inner")
            #Step 4: Get the first token and put in as the text country, not perfect but good enough
            df["textloc"][i] = token_text_country_test["token"][0]
        except IndexError:
            df["textloc"][i] = ""
    
    #Step 5: #Get the coordinates
    #Make the empty dataframes
    kolat = pd.DataFrame([])
    kolong = pd.DataFrame([])
    kotweet_2 = pd.DataFrame([])
    
    #Step 6: Create the lat and long variables to add to the data
    lenkotw = len(df["text"])

    for i in np.arange(0, lenkotw):
        koloc = df["textloc"][i]
        try:
            geo_code_result_ko = gmaps.geocode(koloc)
            #If there is nothing in text_country then do the first part and append (0,0) for coordinates
            if pd.isna(koloc) == True:
                kolat = kolat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
                kolong = kolong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
                kotweet_2 = kotweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            #If the google maps can't find a location for the text country, append (0,0) for coordinates
            elif len(geo_code_result_ko) == 0:
                kolat = kolat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
                kolong = kolong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
                kotweet_2 = kotweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
            #For all else, get the lat and long out of the dictionaries and sub-dictionaries of the google maps 
            #results
            else:
                geo_code_dict_ko = geo_code_result_ko[0]
                geo_code_geometry_dict_ko = geo_code_dict_ko.get('geometry')
                geo_location_ko = geo_code_geometry_dict_ko.get('location')
                kolat = kolat.append(pd.DataFrame({'Lat': geo_location_ko.get('lat')}, index = [0]), ignore_index = True)
                kolong = kolong.append(pd.DataFrame({'Long': geo_location_ko.get('lng')}, index = [0]), ignore_index = True)
                kotweet_2 = kotweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
        except:
            kolat = kolat.append(pd.DataFrame({'Lat': 0}, index = [0]), ignore_index = True)
            kolong = kolong.append(pd.DataFrame({'Long': 0}, index = [0]), ignore_index = True)
            kotweet_2 = kotweet_2.append(pd.DataFrame({'TweetNumber': [i]}, index = [0]), ignore_index = True)
    
    #Step 7: Concatenate dataframes of the Lat and Long
    framesloc_ko = [kolat, kolong]
    finalloc_ko = pd.concat(framesloc_ko, axis = 1)
    
    #Step 8: Left Merge The Lat and Long into to the tweets
    frames_2_ko = [df, finalloc_ko]
    kocoord = pd.concat(frames_2_ko, axis = 1)

    return kocoord


# In[ ]:


#Part 26: The English Analyzer Function
def english_df_2(English_Tweets):
    try:
        english_test_df = english_analysis_2(English_Tweets)
    except KeyError:
        english_test_df = pd.DataFrame()
    
    return english_test_df


# In[ ]:


#Part 27: The Spanish Analyzer Function
def spanish_df_2(Spanish_Tweets):
    try:
        spanish_test_df = spanish_analysis_2(Spanish_Tweets)
    except ValueError:
        spanish_test_df = pd.DataFrame()
        
    return spanish_test_df


# In[ ]:


#Part 28: The French Analyzer Function
def french_df_2(French_Tweets):
    try:
        french_test_df = french_analysis_2(French_Tweets)
    except ValueError:
        french_test_df = pd.DataFrame()
        
    return french_test_df


# In[ ]:


#Part 29: The Portuguese Analyzer Function
def portuguese_df_2(Portuguese_Tweets):
    try:
        portuguese_test_df = portuguese_analysis_2(Portuguese_Tweets)
    except:
        portuguese_test_df = pd.DataFrame()
        
    return portuguese_test_df


# In[ ]:


#Part 30: Call the Arabic Analyzer Function
def arabic_df_2(Arabic_Tweets):
    try:
        arabic_test_df_2 = arabic_analysis_2(Arabic_Tweets)
        arabic_test_df = arabic_test_df_2.loc[:, ~arabic_test_df_2.columns.duplicated()]
    except ValueError:
        arabic_test_df = pd.DataFrame()

    return arabic_test_df


# In[ ]:


#Part 31: Call the Japanese Analyzer Function
def japanese_df_2(Japanese_Tweets):
    try:
        japanese_test_df = japanese_analysis_2(Japanese_Tweets)
    except ValueError:
        japanese_test_df = pd.DataFrame()
    
    return japanese_test_df


# In[ ]:


#Part 32: Call the Korean Analyzer Function
def korean_df_2(Korean_Tweets):
    try:
        korean_test_df = korean_analysis_2(Korean_Tweets)
    except ValueError:
        korean_test_df = pd.DataFrame()
        
    return korean_test_df


# In[1]:


#Part 42: MAP MAKING PART Map the Locations
#Creating the Map Function
def making_map(full_df, counter_2, max_file_name):
    #Get length of data frame
    full_dflen = len(full_df["text"])
    #Initalize Folium Map
    map1_test = folium.Map(
        location = [0.00, 0.00],
        titles = 'cartodbpositron',
        zoom_start = 1 )
    #Map the topics on the Map1_test
    for i in np.arange(0, full_dflen):
        if pd.isna(full_df["label"][i]) == True:
            #Store the no location tweets on the map
            try:
                folium.Marker(
                    location = [full_df["Lat"][i], full_df["Long"][i]],
                    popup = full_df["textloc"][i],
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test)     
        elif full_df["textloc_en"][i] == "RT":
            #Remove the RT from the retweet that gets picked up in the Spacy LOC tag
            try:
                folium.Marker(
                    location = [0, 0],
                    popup = "RT",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Goldstein Negative":
            #Add Goldstein Negative tags to Map
            try:
                folium.Marker(
                    location = [full_df["Lat"][i], (full_df["Long"][i] + 0.5)],
                    popup = (full_df["textloc_en"][i] + ', ' + "Goldstein Negative"),
                    icon = folium.Icon(color = 'red')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Goldstein Positive":
            #Add Goldstein Positive tags to Map
            try:
                folium.Marker(
                    location = [full_df["Lat"][i], (full_df["Long"][i] - 0.5)],
                    popup = (full_df["textloc_en"][i] + ', ' + "Goldstein Positive"),
                    icon = folium.Icon(color = 'blue')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Nuclear Threat":
            #Add Nuclear Threat to Map
            try:
                folium.Marker(
                    location = [(full_df["Lat"][i] + 0.5), (full_df["Long"][i])],
                    popup = (full_df["textloc_en"][i] + ', ' + "Nuclear Threat"),
                    icon = folium.Icon(color = 'lightgreen')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Cyber Warfare":
            #Add Cyber Warfare to Map
            try:
                folium.Marker(
                    location = [(full_df["Lat"][i] - 0.5), (full_df["Long"][i])],
                    popup = (full_df["textloc_en"][i] + ', ' + "Cyber Warfare"),
                    icon = folium.Icon(color = 'gray')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Oil Supply Shock":
            #Add Oil Supply Shock to Map
            try:
                folium.Marker(
                    location = [full_df["Lat"][i], (full_df["Long"][i] + 1)],
                    popup = (full_df["textloc_en"][i] + ', ' + "Oil Supply Shock"),
                    icon = folium.Icon(color = 'black')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "US-China Relations":
            #Add US-China Relations to Map
            try:
                folium.Marker(
                    location = [full_df["Lat"][i], (full_df["Long"][i] - 1)],
                    popup = (full_df["textloc_en"][i] + ', ' + "US-China Relations"),
                    icon = folium.Icon(color = 'purple')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Terrorism":
            #Add Terrorism to Map
            try:
                folium.Marker(
                    location = [(full_df["Lat"][i] + 1), (full_df["Long"][i])],
                    popup = (full_df["textloc_en"][i] + ', ' + "Terrorism"),
                    icon = folium.Icon(color = 'darkred')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        elif full_df["tag"][i] == "Geopolitical Risks":
            #Add Geopolitical Risks to Map
            try:
                folium.Marker(
                    location = [(full_df["Lat"][i] - 1), (full_df["Long"][i])],
                    popup = (full_df["textloc_en"][i] + ', ' + "Geopolitical Risks"),
                    icon = folium.Icon(color = 'darkgreen')
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
        else:
            #Add War Threats to Map
            try:
                folium.Marker(
                    location = [full_df["Lat"][i], (full_df["Long"][i] + 1.5)],
                    popup = (full_df["textloc_en"][i] + ', ' + "War Threats"),
                    icon = folium.Icon(color = "orange")
                ).add_to(map1_test)
            except:
                folium.Marker(
                    location = [0, 0],
                    popup = "Empty",
                    icon = folium.Icon(color = 'white')
                ).add_to(map1_test) 
            
    #Output map
    map1_test.save("/Users/johnc.burns/Documents/Documents/PhD Year Three/My Paper 5/foo9/Output_Files/Maps/map_" + str(max_file_name) + ".html")
    
    ################################################        
    #Display map
    map1_test
    #Look into how to export the map with Selenium 
    ################################################


# In[ ]:


#Step 46: Construct the Main Function 2: The Mapping Make Main Functions
def main_full_2(counter_2):
    #counter_2 = 0
    df = latest_file(folder_path, file_type, counter_2)
    max_file_name = name_latest_file(folder_path, file_type)
    d1 = datetimenow()
    df2 = lang_loop(df)
    df3 = word_count(df2)
    English_Tweets_2 = English_Tweets_Func(df3)
    Spanish_Tweets_2 = Spanish_Tweets_Func(df3)
    French_Tweets_2 = French_Tweets_Func(df3)
    Portuguese_Tweets_2 = Portuguese_Tweets_Func(df3)
    Arabic_Tweets_2 = Arabic_Tweets_Func(df3)
    Japanese_Tweets_2 = Japanese_Tweets_Func(df3)
    Korean_Tweets_2 = Korean_Tweets_Func(df3)
    entweet_coord = english_df_2(English_Tweets_2)
    sptweet_coord = spanish_df_2(Spanish_Tweets_2)
    frtweet_coord = french_df_2(French_Tweets_2)
    pttweet_coord = portuguese_df_2(Portuguese_Tweets_2)
    artweet_coord = arabic_df_2(Arabic_Tweets_2)
    jatweet_coord = japanese_df_2(Japanese_Tweets_2)
    kotweet_coord = korean_df_2(Korean_Tweets_2)
    full_df_2 = create_full(entweet_coord, sptweet_coord, frtweet_coord, pttweet_coord, artweet_coord, jatweet_coord, kotweet_coord)
    full_df_2_no_dups = full_df_no_dups(full_df_2)
    topic_cl_2 = topic_count_list(full_df_2_no_dups)
    tcl_convert(topic_cl_2, d1, max_file_name)
    topic_sl_2 = topic_sentiment_list(full_df_2_no_dups)
    full_topic_sentiment_2 = tsl_convert(topic_sl_2, d1, max_file_name)
    lang_cl = lang_count_list(full_df_2_no_dups)
    lcl_convert(lang_cl, d1, max_file_name)
    count_over_time()
    sentiment_over_time()
    full_df_3 = translate_to_english(full_df_2, counter_2, max_file_name)
    making_map(full_df_3, counter_2, max_file_name)
    country_product(full_df_3, d1, max_file_name, counter_2)
    finance_topic(full_topic_sentiment_2, d1, max_file_name, counter_2)
    counter_2 = counter_updater(counter_2)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




